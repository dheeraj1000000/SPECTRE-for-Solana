# Epic: claudit-metaplex-bubblegum-v1

**Audit:** `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1`
**Repo:** `metaplex-foundation/mpl-bubblegum` @ commit `e9fde975e730f21e8a54a9dc56fd2a5165ac3471`
**Owner:** Metaplex Foundation (public-corpus pass; Pinpoint is the implicit consumer until the maintainers engage)
**Engagement type:** SPECTRE V1 public-corpus audit + claudit-driven triage loop

---

## Vision and overview

The 2026-05-11 SPECTRE scan against `mpl-bubblegum` surfaced 413 raw
findings on the balanced profile with a 0.78 confidence floor. The disproval
pass narrowed these to:

- **0 design-level Criticals.** All 10 detector-High hits (5 CPI-030 +
  5 ACC-013) resolve to known-design or backward-compat artifacts on
  source-level read.
- **2 Medium architectural advisories** (M-001 Compress stub, M-002
  backward-compat `token_metadata_program` fields). Both are NEEDS-DECISION
  items routed to the maintainers; no patch is proposed.
- **9 readiness advisories** (A-001) on high-fan-out V2 handlers.
- **403 lower-confidence** items (LC-001 QUAL-003 cluster) which are
  detector noise on small constructors and Anchor-generated helpers.

Plus a **bidirectional finding**: SPECTRE missed 17 transitive CVEs that
`cargo audit` catches via the `solana-*` / `tokio` / `rustls-webpki` chain.

The scope of this epic's automated change is intentionally narrow.
**Wave 1 is a documented no-op** unless the maintainers opt into an ACK
commit. The interesting motion is Wave 0 (capture baselines) and Wave 2
(re-audit + cross-reference + Pinpoint-side detector tuning ticket).

---

## Architecture

```
+--------------------------------------------------------------------------------+
|              CLAUDIT TRIAGE LOOP - mpl-bubblegum V1                            |
+--------------------------------------------------------------------------------+
|                                                                                |
|   +---------------------+      +---------------------------+                   |
|   |  Audit deliverable  |      |  Customer repo             |                  |
|   |  (this directory)   |      |  mpl-bubblegum @ e9fde97   |                  |
|   |  - findings YAML    |----->|  programs/bubblegum/       |                  |
|   |  - disproval table  |      |  (read-only in Wave 1)     |                  |
|   |  - ACK trailer text |      |                            |                  |
|   +----------+----------+      +-----------+----------------+                  |
|              |                             |                                   |
|              v                             v                                   |
|   +--------------------------------------------------------+                   |
|   |  Wave 0: Pre-flight                                    |                   |
|   |  01 cargo-audit-baseline (capture 17 transitive CVEs)  |                   |
|   |  02 git-state-check (assert HEAD == e9fde97)           |                   |
|   +-------------------------+------------------------------+                   |
|                             |                                                  |
|                             v                                                  |
|   +--------------------------------------------------------+                   |
|   |  Wave 1: Documented no-op (default) OR ACK commit      |                   |
|   |  03 document-compress-stub (surface M-001)             |                   |
|   |  04 document-backcompat-fields (surface M-002)         |                   |
|   |  05 noop-or-commit-with-trailers (conditional)         |                   |
|   +-------------------------+------------------------------+                   |
|                             |                                                  |
|                             v                                                  |
|   +--------------------------------------------------------+                   |
|   |  Wave 2: Re-audit + follow-up                          |                   |
|   |  06 rescan-with-spectre (baseline parity check)        |                   |
|   |  07 prior-audit-crossref (pending PDF supply)          |                   |
|   |  08 qual003-detector-tuning (Pinpoint-side ticket)     |                   |
|   +--------------------------------------------------------+                   |
|                                                                                |
+--------------------------------------------------------------------------------+
```

---

## Components

### 1. Pre-flight (Wave 0, tasks 01 + 02)

- **01 cargo-audit-baseline.** Runs `cargo audit --json` against `programs/bubblegum/Cargo.lock`. Confirms the 17-CVE supplemental list still matches the lockfile. Captures output for archival.
- **02 git-state-check.** Asserts `git rev-parse HEAD == e9fde975e730f21e8a54a9dc56fd2a5165ac3471` and `git status --short` is clean.

### 2. Surface dispositions (Wave 1, tasks 03 + 04)

Both tasks are documentation surfaces, not patches. They produce a one-page
NEEDS-DECISION brief for each Medium finding and stage it for the
maintainers' next review meeting.

### 3. Conditional ACK commit (Wave 1, task 05)

If the maintainers opt in, task 05 lands an ACK-only commit with three
trailers and no source changes:

```
Pinpoint-Finding-Acknowledged: PINPOINT-BUBBLEGUM-M-001
Pinpoint-Finding-Acknowledged: PINPOINT-BUBBLEGUM-M-002
Pinpoint-Scan-Commit: e9fde975e730f21e8a54a9dc56fd2a5165ac3471
```

If they do not opt in, the task is a documented no-op and Wave 1 finishes
without touching the repo.

### 4. Re-audit (Wave 2, task 06)

Confirms baseline parity. If no source change landed, the V2 counts should
match V1 exactly (413 total, 10 High, 171 Medium, 232 Low). If the
maintainers chose to type the `token_metadata_program` fields, CPI-030 will
drop from 5 to 1.

### 5. Follow-up tickets (Wave 2, tasks 07 + 08)

- **07 prior-audit-crossref.** Opens a tracking ticket to source any prior public Bubblegum audit (OtterSec / Halborn / Zellic). If a PDF is supplied, V2 will ship the FIXED / ACK / INVALID / FIX-NEEDED grid.
- **08 qual003-detector-tuning.** Opens a Pinpoint-side ticket to suppress fan-in alarms on small utility constructors. Same fix as matariki LC-003.

---

## Waves

### Wave 0 — Pre-flight (~2 min)

| Task | Title | Depends on |
|------|-------|------------|
| 01 | cargo-audit-baseline | (none) |
| 02 | git-state-check | (none) |

Tasks 01 and 02 are independent; they may run in parallel.

### Wave 1 — Surface dispositions + optional ACK (~3 min)

| Task | Title | Depends on |
|------|-------|------------|
| 03 | document-compress-stub | 02 |
| 04 | document-backcompat-fields | 02 |
| 05 | noop-or-commit-with-trailers | 03, 04 |

### Wave 2 — Re-audit + follow-up (~3 min)

| Task | Title | Depends on |
|------|-------|------------|
| 06 | rescan-with-spectre | 05 |
| 07 | prior-audit-crossref | (none; opens ticket only) |
| 08 | qual003-detector-tuning | (none; opens ticket only, Pinpoint-side) |

---

## Success Criteria

- [ ] Wave 0 pre-flight passes (HEAD at `e9fde97`, working tree clean).
- [ ] `cargo audit --json` reports 17 vulnerabilities (drift surfaced to operator if different).
- [ ] Wave 1 either lands an ACK-only commit (if maintainers opt in) carrying the three Pinpoint-* trailers verbatim, or terminates cleanly as a documented no-op.
- [ ] Wave 2 rescan reports identical counts to V1 (or the predicted delta if maintainers typed M-002 fields).
- [ ] Tasks 07 and 08 produce one tracker ticket each (Linear / Jira / GitHub Issues).

---

## Task Dependencies

```
Phase 0 (pre-flight, parallel):
  01 cargo-audit-baseline      (no deps)
  02 git-state-check           (no deps)

Phase 1 (surface dispositions; both depend on phase-0 git check):
  03 document-compress-stub        (deps: 02)
  04 document-backcompat-fields    (deps: 02)

Phase 2 (conditional ACK commit; depends on both phase-1 docs):
  05 noop-or-commit-with-trailers  (deps: 03, 04)

Phase 3 (re-audit; depends on the commit-or-noop outcome):
  06 rescan-with-spectre           (deps: 05)

Phase 4 (follow-up tickets; independent of triage):
  07 prior-audit-crossref          (no deps; opens ticket only)
  08 qual003-detector-tuning       (no deps; opens ticket only, Pinpoint-side)
```

Critical-path: 02 → 03 → 05 → 06 (~6 min wall-clock).

---

## Risks

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| Working tree not at `e9fde97` | Medium — disproval table line numbers drift | Low | Task 02 asserts `git rev-parse HEAD == e9fde975e730f21e8a54a9dc56fd2a5165ac3471`; halts otherwise. |
| Maintainers want to act on M-001 / M-002 now but the agent applies no patch | Low — false impression of completed work | Medium | Task 05 explicitly distinguishes "ACK-only commit" vs "patch" and refuses to apply source changes; surfaces the three implementation options for M-001 and M-002 to the operator. |
| Re-audit (task 06) reports unexpected delta | Low — confusing operator output | Low | Task 06's expected counts are sourced from `yaml.workflow.re_audit.instruction`; both the "no change" and "M-002 typed" expectations are pre-computed. |
| Prior-audit PDF surfaces after V1 ships | Low — V12-style grid is missing from V1 | Medium | Task 07 explicitly tracks this; once a PDF is supplied, V2 ships the grid. We do not fabricate. |
| Ticket tooling not configured | Low — tasks 07/08 print ticket text instead of filing | Medium | Tasks fall back to printing the ticket body verbatim to stdout. |

## Out of scope

- The 403 LC-001 QUAL-003 findings (detector noise; expect them to collapse on V2 once the Pinpoint-side fan-in suppression lands).
- The 17 transitive CVEs (resolve when `solana-program-sdk` updates its dep pins; optional `deny.toml` template documented in §4c).
- Implementing the `compress` instruction body (M-001 option B).
- IDL-breaking removal of backward-compat `token_metadata_program` fields (M-002 option "drop").

---

## Confidence and rehearsal record

Wave 0 (cargo audit + git state) was rehearsed on 2026-05-11 against
commit `e9fde97`. The disproval table for every detector-High site was
hand-validated against the source files cited in the YAML's
`disproval_table` block. Wave 1 is a documented no-op so there is no patch
to rehearse; Wave 2 task 06 will run a clean baseline parity check.
