# `claudit` — Claude-driven audit triage loop for mpl-bubblegum V1

This directory packages the audit findings (M-001 and M-002 NEEDS-DECISION
items), the disproval table, the cargo-audit supplement, and a SPOQ-style
task graph so an LLM agent (or a human) can run the **pre-flight → surface
dispositions → optional ACK commit → re-audit** loop end-to-end without
copy-paste.

You receive this as part of the SPECTRE V1 deliverable. Hand the audit
project directory to Claude and say:

> *"Run claudit on `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1`."*

Claude will read this README, load the YAML, and execute the tasks in
`claudit/tasks/` in dependency order.

**Wave 1 is intentionally a documented no-op.** Nothing surfaced by V1 is
patchable under the current ruleset; the two Medium findings (M-001, M-002)
are NEEDS-DECISION items routed to the maintainers. Task 05 only commits
an ACK trailer chain if the maintainers explicitly opt in.

---

## What is "claudit"?

A `claudit` is the agent-runnable companion to a static audit report. The
SPECTRE PDF / MD / CSV are for humans; the YAML is for LLMs; this directory
is the **execution plan** which is a small SPOQ-flavoured task graph that
ties everything together.

```
claudit/
├── README.md                                       ← you are here
├── EPIC.md                                         ← architecture, waves, dependency diagram
└── tasks/
    ├── 01-cargo-audit-baseline.yml                 (Wave 0 pre-flight)
    ├── 02-git-state-check.yml                      (Wave 0 pre-flight)
    ├── 03-document-compress-stub.yml               (Wave 1, doc-only)
    ├── 04-document-backcompat-fields.yml           (Wave 1, doc-only)
    ├── 05-noop-or-commit-with-trailers.yml         (Wave 1, conditional)
    ├── 06-rescan-with-spectre.yml                  (Wave 2 verify)
    ├── 07-prior-audit-crossref.yml                 (Wave 2, follow-up)
    └── 08-qual003-detector-tuning.yml              (Wave 2, Pinpoint-side)
```

---

## Pre-flight (one-time, on the operator's machine)

```bash
cargo install cargo-audit
# Solana SBF toolchain not strictly required for this audit; nothing in
# Wave 1 modifies on-chain Rust source.
```

---

## Running the loop

### Option A — autonomous (recommended)

Hand Claude the audit project and the prompt:

> *Read `claudit/README.md` and `claudit/EPIC.md`. Then execute every task
> in `claudit/tasks/` in dependency order, halting on first failure. Wave 1
> is a documented no-op unless the maintainers opt into the ACK commit.*

Claude works through tasks 01 → 06 in one session (~5 minutes), surfaces
tasks 07 and 08 as follow-up tickets, and stops.

### Option B — step-by-step

```bash
# Wave 0: pre-flight
claude run claudit/tasks/01-cargo-audit-baseline.yml
claude run claudit/tasks/02-git-state-check.yml

# Wave 1: surface dispositions (doc-only unless maintainers opt in)
claude run claudit/tasks/03-document-compress-stub.yml
claude run claudit/tasks/04-document-backcompat-fields.yml
claude run claudit/tasks/05-noop-or-commit-with-trailers.yml

# Wave 2: re-scan and follow-up tickets
claude run claudit/tasks/06-rescan-with-spectre.yml
claude run claudit/tasks/07-prior-audit-crossref.yml
claude run claudit/tasks/08-qual003-detector-tuning.yml
```

---

## Confidence

Wave 0 (cargo audit + git state) was rehearsed by Pinpoint on 2026-05-11 on
the same commit. The disproval table for every detector-High site was
hand-validated against source. No Rust source changes are proposed in V1,
so there is no patch to rehearse.
