# 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1

**Customer:** Metaplex Foundation (public-corpus scan) &nbsp;·&nbsp; **Project:** `mpl-bubblegum` (compressed-NFT program on Solana)
**Scan commit:** `e9fde975e730f21e8a54a9dc56fd2a5165ac3471` &nbsp;·&nbsp; **Engine:** Pinpoint SPECTRE v0.1.0
**Date:** 2026-05-11 &nbsp;·&nbsp; **Version:** V1 (public-corpus pass)

---

## What this is

This directory is a complete SPECTRE audit deliverable for Metaplex's
compressed-NFT (cNFT) program. It is a public-good audit, so the protocol
team is the implicit consumer. Everything needed to **read the audit,
evaluate the architectural-signal hits, and drive a follow-up engagement**
is in here. No external fetches.

**Outcome:**

- **0 design-level Criticals.** None of the 10 High-severity detector hits
  survive source-level read as exploitable. Five trip on backward-compat
  artifacts (`token_metadata_program` kept on accounts structs for ABI
  stability, no CPI uses it). Five trip on `mut` accounts whose authority
  is enforced one CPI hop away by the underlying program
  (mpl-token-metadata, spl-account-compression) or by Anchor-typed account
  discrimination.
- **2 Medium architectural advisories.** The Compress instruction is still
  a no-op stub (`// TODO`) yet ships full account validation surface in
  the `Compress` struct (M-001). Several `token_metadata_program` accounts
  marked "no longer needed but kept for backwards compatibility" remain
  unconstrained (M-002); they are not exploitable today but invite drift.
- **9 readiness advisories** (A-001) which are high-fan-out helpers in the
  V2 processor path, mirroring the same "audit-readiness, not correctness"
  category that matariki carries.
- **403 lower-confidence** items, all `QUAL-003` fan-in / fan-out alarms on
  small constructors and Anchor-generated helpers. These map to detector
  improvements on the Pinpoint side, not to code changes in mpl-bubblegum.
- **Prior-audit cross-check:** we could not confirm a public Bubblegum
  audit report from OtterSec / Halborn / Zellic in this triage window, so
  the matariki V12 cross-reference table is **intentionally omitted**
  rather than fabricated. We flag this as an open follow-up for V2.
- **Bidirectional finding:** SPECTRE missed 17 transitive CVEs that
  `cargo audit` catches via the `solana-*` / `tokio` / `rustls-webpki`
  chain. Supplemental list in §4c of the PDF.

## Reading order

If you want to **understand what we found** → start with the PDF.
If you want to **drive the follow-up engagement on the Compress stub** → start at `claudit/README.md`.

| # | File | Audience | Time |
|---|---|---|---|
| 1 | `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.pdf` | Humans, end-to-end read | ~10 min |
| 2 | `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.md` | Same content as PDF, paste-ready for review threads | — |
| 3 | `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.yml` | LLM agents / CI / ticket import | self-contained |
| 4 | `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.csv` | Spreadsheets / triage boards (413 rows) | — |
| 5 | `claudit/README.md` | Agent-runnable Wave 0 / Wave 2 entry point | ~5 min agent run |

## Directory layout

```
260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1/
├── README.md                                              ← you are here
│
├── 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.pdf         ← human-readable report (if built)
├── 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.tex         ← LaTeX source for the PDF
├── 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.md          ← markdown mirror
├── 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.yml         ← agent-feedable YAML
├── 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.csv         ← flat triage table (413 rows)
├── 260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1.scan.json   ← raw SPECTRE JSON (12 MB)
│
└── claudit/                                               ← agent-runnable epic
    ├── README.md                                          ← entry point
    ├── EPIC.md                                            ← architecture, waves, risks
    └── tasks/
        ├── 01-cargo-audit-baseline.yml                    (Wave 0)
        ├── 02-git-state-check.yml                         (Wave 0)
        ├── 03-document-compress-stub.yml                  (Wave 1, doc-only)
        ├── 04-document-backcompat-fields.yml              (Wave 1, doc-only)
        ├── 05-noop-or-commit-with-trailers.yml            (Wave 1)
        ├── 06-rescan-with-spectre.yml                     (Wave 2)
        ├── 07-prior-audit-crossref.yml                    (Wave 2, follow-up)
        └── 08-qual003-detector-tuning.yml                 (Wave 2, Pinpoint-side)
```

## TL;DR — what to do with this

Bubblegum V1 has **no patchable security defect** under the V1 ruleset.
Wave 1 is therefore a documented no-op: we ask the maintainers to confirm
the Compress stub is intentional (the handler body is `// TODO`) and to
keep the backward-compat `token_metadata_program` fields on the radar for
a future cleanup pass. The interesting motion is Wave 2: cross-checking
against any prior published audit, and running `cargo audit` to surface
the transitive dependency CVEs that SPECTRE's `DEPVULN-001` does not catch.

```bash
# 1. Pre-flight (one time, on your machine)
cargo install cargo-audit

# 2. Hand the audit project to your Claude:
#    "Read claudit/README.md and claudit/EPIC.md. Then execute every task in
#     claudit/tasks/ in dependency order, halting on the first failure."

# 3. After Claude finishes Wave 0, re-scan to confirm baseline:
pinpoint spectre scan . --local --output json --profile balanced \
  --min-confidence 0.78 --languages rust
# Expected: 413 findings; 10 High (5 CPI-030 + 5 ACC-013), 171 Medium, 232 Low.
```

## What's been validated end-to-end

| Phase | Command | Result |
|---|---|---|
| Scan reproduction | `pinpoint spectre scan ... --profile balanced --min-confidence 0.78` | 413 findings, top rules QUAL-003 ×403, CPI-030 ×5, ACC-013 ×5 |
| Architectural-signal triage | manual read of `Compress`, `CollectV2`, `CollectionVerification`, `MintToCollectionV1`, `UpdateMetadata` | 10 / 10 sites resolved to known-design or backward-compat; 0 exploitable |
| `cargo audit --json` baseline | `cargo audit --json` against `programs/bubblegum/Cargo.lock` | 17 transitive CVEs surfaced (bytes, crossbeam-channel, curve25519-dalek, ed25519-dalek, h2 ×2, idna, quinn-proto, ring ×2, rustls-webpki ×3, tar ×2, time, tracing-subscriber) |
| Prior-audit search | OtterSec / Halborn / Zellic public corpora | Not confirmed in triage window; V12 cross-ref omitted by policy |

## Naming convention

Pinpoint deliverables follow `YYMMDD-SPECTRE-AUDIT-CUSTOMER-PROJECT-Vn`.
This is V1. After we confirm a prior audit reference (or the maintainers
confirm the Compress stub disposition), we will ship V2 with the V12-style
cross-reference table populated.

---

## Questions

This is a public-corpus pass; there is no direct customer thread. If you
are on the Metaplex team and want to engage formally, reach out to
Pinpoint via the contact channel on testwithpinpoint.com.
