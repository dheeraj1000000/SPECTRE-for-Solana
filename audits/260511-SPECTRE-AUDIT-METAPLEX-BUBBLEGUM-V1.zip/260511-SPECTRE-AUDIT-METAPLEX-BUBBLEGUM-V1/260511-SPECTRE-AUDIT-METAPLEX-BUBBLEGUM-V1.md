# SPECTRE AUDIT — Metaplex Foundation / mpl-bubblegum

**Filename:** `260511-SPECTRE-AUDIT-METAPLEX-BUBBLEGUM-V1`

| | |
|---|---|
| **Customer** | Metaplex Foundation (public-corpus scan) |
| **Project** | `mpl-bubblegum` which is the compressed-NFT (cNFT) program on Solana |
| **Scan commit** | `e9fde975e730f21e8a54a9dc56fd2a5165ac3471` (`e9fde97`) |
| **Engine** | Pinpoint SPECTRE v0.1.0 (`--features internal`) |
| **Profile run** | balanced (`--min-confidence 0.78`, `--languages rust`); raw count 413 |
| **Date** | 2026-05-11 |
| **Report version** | V1 (public-corpus pass) |
| **Critical Findings** | **0** (10 detector-High hits all resolve to known-design or backward-compat artifacts) |
| **Other Findings** | 2 medium architectural advisories (Compress stub, backward-compat fields) · 9 readiness advisories (handler complexity) · 403 lower-confidence (QUAL-003 cluster) |
| **Validation** | **Read-level**, so every High-confidence site was re-read in source; no patch applied because nothing is patchable under the V1 ruleset |
| **Prior-audit cross-check** | Not confirmed in triage window; matariki-style V12 grid omitted by policy (do not fabricate) |

---

## Executive summary

**What we did.** We ran SPECTRE against `mpl-bubblegum` at HEAD (`e9fde97`)
with the balanced profile and a `0.78` minimum-confidence floor, restricted
to Rust. The raw count was **413 findings** across three rule families:
`QUAL-003` (403), `CPI-030` (5), `ACC-013` (5). We then applied SPECTRE's
disproval pass, re-reading every High-severity site against the source and
classifying the rest by rule family.

**Headline result.** SPECTRE surfaces **zero exploitable defects** in
`mpl-bubblegum` under the V1 ruleset. The 10 High-severity detector hits
split into two architectural-signal clusters which both resolve to
known-design or backward-compat artifacts on read:

- **CPI-030 x5** on `lib.rs` instruction stubs where the `token_metadata_program` field appears on an accounts struct without an `#[account(address = ...)]` constraint. Four of the five are flagged on accounts structs (`MintToCollectionV1`, `UpdateMetadata`, `CollectionVerification`, `Compress`) where the field carries the doc comment `/// CHECK: This is no longer needed but kept for backwards compatibility.` and no handler performs a CPI through it. The fifth (`Compress::token_program`) is on a no-op stub handler.
- **ACC-013 x5** on `mut` accounts whose authority is enforced one CPI hop away by the underlying program (mpl-token-metadata's collection authority check, spl-account-compression's tree-authority check) or by Anchor's typed account discrimination (so `Account<'info, TreeConfig>` only deserialises a Bubblegum-owned PDA).

**The one architectural signal worth surfacing** is that the `compress`
instruction handler is still a no-op stub (`// TODO`) but ships a full
account validation surface in the `Compress` struct. That mismatch is not
exploitable today since the handler does nothing, but it does mean the
account-shape contract is published in the IDL ahead of the implementation.
We flag it as M-001 and ask the maintainers to confirm intent.

**Prior-audit cross-check.** We searched OtterSec, Halborn, and Zellic
public corpora for a published `mpl-bubblegum` report. We could not confirm
one in the triage window. Per audit policy we **do not fabricate** the V12
cross-reference table; it is omitted from V1 and listed as an explicit
follow-up for V2.

**Bidirectional finding.** As a side-channel signal, we cross-checked
SPECTRE against `cargo audit` on `programs/bubblegum/Cargo.lock`. SPECTRE's
`DEPVULN-001` detector did not surface any of these because it walks
`Cargo.toml` semver, not the lockfile. `cargo audit` reports **17 transitive
CVEs** that SPECTRE missed entirely. All transitive via the `solana-*` /
`tokio` / `rustls-webpki` chain. Supplemental list in §4c. Detector
improvement on the Pinpoint side: walk `Cargo.lock`, not `Cargo.toml`.

The remaining 403 findings are the `QUAL-003` cluster of small
constructors, Anchor-generated helpers (`default`, `try_to_vec`), and
inline trait implementations getting flagged for fan-in or fan-out. None
require code change in `mpl-bubblegum`; all map to detector improvements
in the Pinpoint engine.

### How this report is laid out

1. **Executive summary** which is method, headline, layout (this section).
2. **Findings snapshot** which is the one-table view of the two Medium advisories.
3. **Detailed Finding Records** for M-001 (Compress stub) and M-002 (backward-compat fields).
4. **Other Findings appendix** with the High-severity disproval table, readiness advisories (A-001), lower-confidence (LC-001).
4b. **Prior-audit cross-check** is omitted; see V2 follow-up note.
4c. **`cargo audit` supplement** lists 17 transitive CVEs SPECTRE missed.
5. **Workflow integration and delivery channels** which is how this report fits into the audit loop.
6. **Claudit** which is the agent-runnable companion epic at `claudit/`.

### Three views, one source of truth

| Artifact | Audience | What it is for |
|---|---|---|
| `…BUBBLEGUM-V1.pdf` | Humans | Executive narrative; what to read end-to-end. |
| `…BUBBLEGUM-V1.md` | Slack / email / review threads | Same content as the PDF in plain Markdown. |
| `…BUBBLEGUM-V1.yml` | Agents / CI / ticket import | One YAML record per finding family with finding ID, scan commit, severity, confidence, classification rationale, and ticket-lifecycle metadata. |
| `…BUBBLEGUM-V1.csv` | Spreadsheets / triage boards | Flat row-per-finding view (413 rows); sortable, filterable, joinable to existing trackers. |

---

## 1. Findings snapshot

| ID | Class | Sev | Conf. | Title |
|---|---|---|---|---|
| `M-001` | architectural | Medium | High | Compress instruction is a no-op stub but ships full account validation surface |
| `M-002` | doc / hygiene | Medium | High | Backward-compat `token_metadata_program` fields remain unconstrained (4 sites) |
| `A-001` | advisory | Medium | Medium | High-fan-out instruction handlers in the V2 processor path (9 sites) |
| `LC-001` | lower-conf. | Low\* | Unlikely | QUAL-003 fan-in / fan-out alarms on small constructors and Anchor helpers (403 sites) |

\* Severity is the rule's raw classification; confidence is our verified
read. "Lower-confidence" findings should drive detector tuning, not code
change in `mpl-bubblegum`.

There is no `C-001` row this round because the 10 detector-High hits all
resolve to known-design or backward-compat artifacts. See §4 disproval table.

---

## 2. Detailed Finding Records

### `PINPOINT-BUBBLEGUM-M-001` — `compress` instruction stub

| | |
|---|---|
| **Rule** | architectural (manual, derived from CPI-030 + ACC-013 cluster on `Compress`) |
| **Severity** | Medium |
| **Confidence** | High |
| **Profile** | n/a (manual finding from disproval pass) |
| **Disposition** | NEEDS-DECISION (intent confirmation from maintainers) |

**Affected location:** `programs/bubblegum/program/src/processor/compress.rs:6-44`.

**Description.** The `Compress` accounts struct (lines 6 to 39) ships a
complete account validation surface: `tree_authority` PDA, `leaf_owner`
Signer, `merkle_tree` UncheckedAccount, mutable `token_account`, mutable
`mint`, mutable `metadata` (TokenMetadata), mutable `master_edition`
(MasterEdition), `payer` Signer, plus the standard helper programs. The
handler body, however, is exactly:

```rust
pub(crate) fn compress(_ctx: Context<Compress>) -> Result<()> {
    // TODO
    Ok(())
}
```

The instruction registers in `lib.rs:167`, returns `Ok(())` unconditionally,
and does not touch any of the accounts it declares. Today this is not
exploitable because the program performs no action, so no authority check
is needed. It is, however, an **unusual contract shape**: the IDL publishes
account slots that callers must fill, but the program ignores them. Anchor
still deserialises and validates the typed accounts
(`Box<Account<TokenMetadata>>` will reject any account whose data does not
deserialise to a Token Metadata record owned by `mpl-token-metadata`), so
the invariant cost is bounded by the deserialiser, not by handler logic.

**Impact.** Two failure modes worth surfacing to the maintainers:

1. **Drift risk.** If a future PR adds a body to `compress`, the author may reasonably assume "the account shape was validated by the audit." Today's `Compress` struct passes Anchor's deserialiser checks but does **not** enforce a `has_one` or constraint linking `metadata` / `master_edition` to `mint`, nor an authority check on `leaf_owner` against the on-chain leaf state. Any non-trivial body added later would need to add those constraints before the handler is safe to land.
2. **IDL surface area.** The instruction appears in the IDL with a full account list and a hash that integrators can consume. If the team intends to remove the instruction, deprecating the IDL slot now is cleaner than removing it later.

**Suggested actions (NEEDS-DECISION, NOT a patch).**

- **Option A (keep stub).** Add a `#[deprecated]` doc comment on `pub fn compress` and a `BubblegumError::NotImplemented` early return so the handler fails explicitly rather than silently succeeding. Callers learn the instruction is non-functional via on-chain error rather than via silent no-op.
- **Option B (implement).** Confirm the planned semantics (compress an existing uncompressed NFT into a tree) and tighten the `Compress` struct: add `has_one = mint` on `metadata` and `master_edition`, gate via `leaf_owner: Signer` matching the current `token_account` owner, and require `tree_delegate` authority on `tree_authority`.
- **Option C (remove).** Drop the instruction registration in `lib.rs:167` and remove `processor/compress.rs`. IDL consumers carrying a stale binding will need a version bump.

**Why this is M-001 and not a C-001.** The handler is a no-op. No accounts
are mutated. The protocol cannot be exploited via this instruction today.
The finding is about long-term contract hygiene, not about a current
vulnerability.

### `PINPOINT-BUBBLEGUM-M-002` — backward-compat `token_metadata_program` fields

| | |
|---|---|
| **Rule** | CPI-030 (manual reclassification from High to Medium after disproval) |
| **Severity** | Medium |
| **Confidence** | High |
| **Profile** | balanced |
| **Disposition** | DOCUMENT (no immediate action; flag for next cleanup pass) |

**Affected locations** (all with the doc comment `/// CHECK: This is no longer needed but kept for backwards compatibility.`):

- `programs/bubblegum/program/src/processor/mint_to_collection.rs:50` — `MintToCollectionV1::token_metadata_program`
- `programs/bubblegum/program/src/processor/verify_collection.rs:45` — `CollectionVerification::token_metadata_program`
- `programs/bubblegum/program/src/processor/update_metadata.rs:55` — `UpdateMetadata::token_metadata_program`
- `programs/bubblegum/program/src/processor/compress.rs:37` — `Compress::token_metadata_program` (covered also by M-001)

**Description.** Each accounts struct above carries an
`UncheckedAccount<'info>` field named `token_metadata_program` without an
`#[account(address = mpl_token_metadata::ID)]` constraint. SPECTRE's
`CPI-030` detector flags these as program-typed accounts that callers can
substitute. The doc comment on every site states the field is no longer
used. We grep-confirmed that no `processor/*` body performs a CPI through
these specific fields; the only real CPI to `mpl-token-metadata` lives in
`decompress.rs` and uses a typed `Program<'info, MplTokenMetadata>` (which
Anchor address-checks automatically).

**Impact.** **No current exploit.** Anchor will accept any account in the
slot, but since no handler reads or invokes through it, the worst-case
behaviour is a transaction whose IDL-declared accounts include a junk
pubkey for a slot the program ignores. The drift risk is the concern, so
if a future PR re-introduces a CPI through one of these slots without
first typing the field as `Program<'info, MplTokenMetadata>`, the
re-introduction would be a fresh `CPI-030` vulnerability.

**Suggested action (NEEDS-DECISION, NOT a patch).** Two cleanup paths,
both backward-compatible at the IDL level if done carefully:

- **Type the field.** Replace `pub token_metadata_program: UncheckedAccount<'info>` with `pub token_metadata_program: Program<'info, MplTokenMetadata>`. Anchor enforces the program ID at deserialisation. Callers passing the correct ID see no change; callers passing junk break immediately. This is the right shape for the slot's name.
- **Drop the field.** If the IDL slot can be removed (no integrator is known to fill it from existing client SDKs), removing the field is cleaner. This is an IDL-breaking change that needs a version bump.

We recommend **typing** over **dropping** unless the maintainers know the
IDL slot is safely retirable.

---

## 4. Other Findings — appendix

### High-severity disproval table

Every detector-High finding was re-read in source and classified. None survived as exploitable.

| Site | Rule | Detector Sev | Disposition | Rationale |
|---|---|---|---|---|
| `lib.rs:167` (Compress) | CPI-030 | High | KNOWN-DESIGN / M-001 | Handler is `// TODO`; no CPI; backward-compat field. |
| `lib.rs:167` (Compress::token_program) | CPI-030 | High | KNOWN-DESIGN / M-001 | Same handler, no CPI. |
| `lib.rs:283` (MintToCollectionV1::token_metadata_program) | CPI-030 | High | BACKWARD-COMPAT / M-002 | Field marked obsolete; CPI in this handler does not use it. |
| `lib.rs:571` (UpdateMetadata::token_metadata_program) | CPI-030 | High | BACKWARD-COMPAT / M-002 | Same shape. |
| `lib.rs:606` (CollectionVerification::token_metadata_program) | CPI-030 | High | BACKWARD-COMPAT / M-002 | Same shape. |
| `compress.rs:27` (Compress::metadata) | ACC-013 | High | KNOWN-DESIGN / M-001 | Stub handler; account never written. |
| `compress.rs:29` (Compress::master_edition) | ACC-013 | High | KNOWN-DESIGN / M-001 | Stub handler; account never written. |
| `collect.rs:11` (CollectV2::tree_authority) | ACC-013 | High | KNOWN-DESIGN | Permissionless fee-sweep into a hardcoded `COLLECT_RECIPIENT` (line 13); intentional public collector. |
| `verify_collection.rs:37` (CollectionVerification::collection_metadata) | ACC-013 | High | DELEGATED-CHECK | Mutation occurs via CPI to mpl-token-metadata; the downstream program enforces collection authority via `assert_authority_matches_collection`. |
| `mint_to_collection.rs:42` (MintToCollectionV1::collection_metadata) | ACC-013 | High | DELEGATED-CHECK | Same shape; `collection_authority: Signer` (line 34) is the on-chain authority enforced before any CPI. |

### `A-001` — high-fan-out instruction handlers (advisory; 9 sites)

Nine handlers in the V2 processor path exceed the `QUAL-003` fan-out
threshold. Same shape as matariki's `A-001` and matariki's prior triage
round: deep handlers that inline validation, CPI, and state mutation in a
single body. Audit-readiness concern, not a correctness defect.

We list the family rather than each site here because the `csv` already
carries the per-site detail and the recommendation is the same for all,
which is to extract `validate_*` / `prepare_*` / `execute_*` helpers so
future external audits move faster. Tackle the top-3 hot handlers first.

### Lower-confidence findings (detector tuning, not code change)

| ID | Rule | Sites | Why lower-confidence | Detector improvement |
|---|---|---:|---|---|
| `LC-001` | QUAL-003 | 403 | All sites are small constructors (`new`, `default`), Anchor-generated trait helpers (`try_to_vec`, `try_from_slice_unchecked`), and inline `From` / `Into` implementations. High fan-in is the design (shared utility code), not a smell. | Suppress fan-in alarms on small utility constructors (LOC < 10, no fan-out, name in {`new`, `default`, `with_capacity`, `build`, `from`, `try_from`, `try_to_vec`, `try_from_slice_unchecked`}). Same fix as matariki LC-003 (and same Pinpoint-side detector ticket). |

---

## 4b. Prior-audit cross-check

**Omitted by policy.** We searched OtterSec, Halborn, and Zellic public
corpora for a published `mpl-bubblegum` audit report during this triage
window. We could not confirm a specific published report in time. Per audit
policy we do not fabricate the V12-style cross-reference table.

If a Metaplex maintainer points us at a PDF (or a public GitHub mirror), V2
of this audit will ship the FIXED / ACK / INVALID / FIX-NEEDED grid the same
way matariki V1 did against V12.

---

## 4c. `cargo audit` supplement

We cross-checked SPECTRE against `cargo audit` (database current to
2026-05-11) on `programs/bubblegum/Cargo.lock`. SPECTRE's `DEPVULN-001`
detector did not surface any of these because it walks `Cargo.toml` semver
rather than the resolved lockfile. `cargo audit` reports **17 transitive
CVEs**. All transitive via the `solana-*` / `tokio` / `rustls-webpki` SDK
chain; the `mpl-bubblegum` workspace does not depend on any of them
directly. Most resolve when `solana-program-sdk` updates its `dalek` /
`rustls-webpki` / `h2` / `ring` / `tar` pins.

| Advisory | Package | Lockfile version | Patched in | Title |
|---|---|---|---|---|
| RUSTSEC-2026-0007 | bytes | 1.7.1 | `>=1.11.1` | Integer overflow in `BytesMut::reserve` |
| RUSTSEC-2025-0024 | crossbeam-channel | 0.5.13 | `>=0.5.15` | crossbeam-channel: double free on Drop |
| RUSTSEC-2024-0344 | curve25519-dalek | 3.2.1 | `>=4.1.3` | Timing variability in `Scalar29::sub`/`Scalar52::sub` |
| RUSTSEC-2022-0093 | ed25519-dalek | 1.0.1 | `>=2` | Double Public Key Signing Function Oracle Attack |
| RUSTSEC-2024-0332 | h2 | 0.3.20 | `^0.3.26`, `>=0.4.4` | DoS in h2 servers from CONTINUATION flood |
| RUSTSEC-2024-0003 | h2 | 0.3.20 | `^0.3.24`, `>=0.4.2` | Resource exhaustion in h2 (DoS) |
| RUSTSEC-2024-0421 | idna | 0.5.0 | `>=1.0.0` | `idna` accepts Punycode labels that do not produce non-ASCII |
| RUSTSEC-2026-0037 | quinn-proto | 0.10.6 | `>=0.11.14` | Denial of service in Quinn endpoints |
| RUSTSEC-2025-0009 | ring | 0.16.20 | `>=0.17.12` | Some AES functions may panic when overflow checking is enabled |
| RUSTSEC-2025-0009 | ring | 0.17.8 | `>=0.17.12` | Same advisory; second lockfile resolution |
| RUSTSEC-2026-0104 | rustls-webpki | 0.101.7 | `>=0.103.13` | Reachable panic in CRL parsing |
| RUSTSEC-2026-0099 | rustls-webpki | 0.101.7 | `>=0.103.12` | Name constraints accepted for wildcard certificates |
| RUSTSEC-2026-0098 | rustls-webpki | 0.101.7 | `>=0.103.12` | Name constraints for URI names incorrectly accepted |
| RUSTSEC-2026-0068 | tar | 0.4.41 | `>=0.4.45` | tar-rs incorrectly ignores PAX size headers |
| RUSTSEC-2026-0067 | tar | 0.4.41 | `>=0.4.45` | `unpack_in` can chmod arbitrary directories by following symlinks |
| RUSTSEC-2026-0009 | time | 0.3.24 | `>=0.3.47` | Denial of Service via stack exhaustion |
| RUSTSEC-2025-0055 | tracing-subscriber | 0.3.17 | `>=0.3.20` | Logging user input may poison logs with ANSI escape sequences |

**Recommended action.** Track `solana-program-sdk` upgrade cadence; revisit
`cargo audit` on each `solana-*` bump. If you wish to silence the noise
during normal development, ship a `deny.toml` with explicit `RUSTSEC-*`
ignore entries that document the transitive-via-solana rationale.

**Detector improvement on Pinpoint side (logged internally).**
`DEPVULN-001` should walk `Cargo.lock` rather than matching `Cargo.toml`
semver. Same change closes the bidirectional gap surfaced by matariki V1.

---

## 5. Workflow integration and delivery channels

### The audit loop, in detail

1. **Audit.** The four artifacts above (`.pdf` / `.md` / `.yml` / `.csv`) plus the raw `.scan.json`.
2. **Feed.** Drop the `.yml` into your LLM (or Pinpoint MCP server); each finding family is self-contained.
3. **Decide.** M-001 and M-002 are both NEEDS-DECISION rather than patches. The maintainers pick the option that matches intent (stub, implement, or remove; type or drop the backward-compat field), then ship a single commit with the corresponding `Pinpoint-Finding-Acknowledged:` trailer or a `Pinpoint-Finding:` trailer if they chose to patch.
4. **Re-audit.** Run `pinpoint spectre scan` against the remediation commit. If the maintainers chose to type the `token_metadata_program` fields, CPI-030 should drop from 5 to 1 (only the Compress site remains). If they chose to gate the `compress` handler with an explicit `NotImplemented` error, ACC-013 sites on `Compress` will remain by detector design but the architectural concern is closed.

### Suggested order of work

1. **This sprint — decide on M-001.** Confirm whether `compress` is intentionally a stub. If yes, add the `NotImplemented` guard. If no, schedule the implementation PR and the matching account-shape tightening.
2. **Next sprint — decide on M-002.** Either type the four `token_metadata_program` fields as `Program<'info, MplTokenMetadata>` or drop them with a version bump.
3. **Pinpoint-side, parallel.** `DEPVULN-001` lockfile walking and `QUAL-003` constructor suppression land in the next engine release; on V2 of this audit, LC-001 will collapse from 403 to a much smaller residual.

### Naming and versioning

Every Pinpoint deliverable follows `YYMMDD-SPECTRE-AUDIT-CUSTOMER-PROJECT-Vn`. This report is V1.

---

## 6. Claudit — the agent-runnable epic

This audit ships an agent-runnable companion epic at `claudit/`. Because
Wave 1 has no patchable item under the V1 ruleset, the epic is structured
as a **documented no-op for Wave 1** plus a **substantive Wave 0 and Wave 2**.

### Wave structure

| Wave | Tasks | Purpose |
|---|---|---|
| Wave 0 | 01 cargo-audit-baseline · 02 git-state-check | Pre-flight: capture `cargo audit` baseline (17 CVEs), assert HEAD is `e9fde97`. |
| Wave 1 | 03 document-compress-stub · 04 document-backcompat-fields · 05 noop-or-commit-with-trailers | Documentation pass: if the maintainers want to ship an ACK commit recording the M-001 and M-002 dispositions, the trailers and prose are pre-written. If they prefer to wait for V2, Wave 1 is a true no-op. |
| Wave 2 | 06 rescan-with-spectre · 07 prior-audit-crossref · 08 qual003-detector-tuning | Re-audit, prior-audit cross-reference (if a PDF is supplied), and Pinpoint-side detector tuning ticket. |

Read more about the SPOQ methodology and rubric at [spoqpaper.com](https://spoqpaper.com).

---

Reply via the contact channel on testwithpinpoint.com, or once intent on
M-001 and M-002 is confirmed we will re-scan and ship V2 with the prior-audit
cross-reference grid populated.
