# SPECTRE AUDIT — Tensor Foundation / marketplace

**Filename:** `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1`

| | |
|---|---|
| **Customer** | Tensor Foundation (public corpus pass; no engagement) |
| **Project** | `marketplace` (on-chain NFT marketplace program: `TCMPhJdwDryooaGtiocG1u3xcYbRpiJzb283XfCZsDp`) |
| **Repo** | https://github.com/tensor-foundation/marketplace |
| **Scan commit** | `8be7f2c3d60c18871e0913b5f837408eeb69047d` (`8be7f2c`) |
| **Engine** | Pinpoint SPECTRE v0.1.0 (`--features internal`) |
| **Profile** | `balanced` · `--min-confidence 0.78` · `--languages rust` |
| **Date** | 2026-05-11 |
| **Report version** | V1 (public-corpus scan, no published reference audit located) |
| **Critical Findings** | **0** confirmed exploitable on read-through |
| **Medium Findings** | **1 cluster** (`M-001`, CPI-030 ×12: unconstrained CPI program-account fields on the WNS surface) |
| **Advisory Findings** | **1 cluster** (`A-001`, QUAL-003 ×45 on hand-written program code: handler complexity; audit-readiness, not security) |
| **Lower-confidence** | **2 groups** (`LC-001`, GOV-001 ×7: detector miscategorised user-owned state mutations as admin-privileged; `LC-002`, QUAL-003 ×360 on auto-generated Codama client code) |
| **Validation** | Read-only audit. Findings resolved to file:line and re-read against source at `8be7f2c`. No patches applied because no clear FIX action lands without protocol input. |
| **Prior audit cross-ref** | Tensor's `SECURITY.md` lists an email-disclosure path. We searched public sources for a published audit report (Ottersec / Zellic / Halborn / Certora) and could not confirm one is available. Cross-reference section omitted in favour of a clean V1 baseline. |

---

## Executive summary

**What we did.** We ran SPECTRE against the public `tensor-foundation/marketplace` repository at HEAD commit `8be7f2c`, on the `balanced` profile with a `0.78` minimum confidence floor. The scan returned **424 raw findings** across three rules: `QUAL-003` ×405, `CPI-030` ×12, `GOV-001` ×7. We then ran SPECTRE's disproval pass: every candidate was re-read against the source, the detector reasoning was reconciled against the Anchor accounts struct, and findings were sorted into Medium / Advisory / Lower-confidence buckets per the matariki-V1 taxonomy.

**Headline result.** Zero exploitable Critical defects on read-through. The single material engineering concern is the **CPI-030 cluster on the WNS handler surface** (`M-001`): six `BuyWns`, `BuyWnsSpl`, `DelistWns`, `TakeBidWns`, `ListWns`, `CloseExpiredListingWns` accounts structs expose `wns_program` and `distribution_program` fields as `UncheckedAccount` with no `#[account(address = …)]` constraint and no in-handler pubkey check. The program comments record an intentional design choice ("checked on approve CPI"), meaning Tensor relies on the WNS / distribution programs to reject CPI calls that originate against a substituted program-account. That defense holds for any honest target program, but the on-chain program-id pin is missing. We classify this Medium and recommend either an `address = wen_new_standard::ID` constraint or a `require_keys_eq!` validate hook. The same shape recurs across six handlers, so it is one decision repeated twelve times.

**False-positive clusters.** The headline rule-count number is dominated by detector noise:

- **GOV-001 ×7 are all false positives.** The detector flagged `edit`, `delist`, `delist_t22`, `delist_wns`, `delist_core`, `delist_legacy`, and `cancel_bid` as "admin-privileged instructions without a timelock". Read against the source, every one of these is a user-owned action: the accounts structs gate the handler on `has_one = owner` (or `has_one = bidder`) with the owner/bidder as a `Signer`. There is no admin role in the marketplace program. The detector pattern-matched on "an Anchor instruction mutates a state account" and inferred admin context where none exists. Logged as `LC-001`; detector-side fix on the Pinpoint engine.
- **QUAL-003 ×405 are 89 percent detector noise.** 360 of the 405 sites are in `clients/rust/src/generated/` (Codama / Kinobi auto-generated client code). The high fan-in on `default()`, `from()`, and `new()` reflects the codegen pattern, not handcrafted complexity. The remaining 45 sites are on hand-written program code where fan-out genuinely is high on hot buy/take_bid handlers; these constitute the `A-001` advisory cluster.

**Workflow validation.** We ran `cargo audit --json` against the workspace `Cargo.lock` (269 packages). It surfaces **2 hard vulnerabilities and 11 warning-class advisories** (5 unmaintained, 6 unsound, 2 yanked). The 2 hard CVEs (`RUSTSEC-2024-0344` curve25519-dalek timing, `RUSTSEC-2022-0093` ed25519-dalek oracle attack) are transitive via the `solana-program 1.16.25` / `solana-sdk 1.16.25` chain. The `marketplace-program` crate does not depend on either directly. Same Pinpoint detector-gap signal as the matariki audit: `DEPVULN-001` did not surface in this scan because no Cargo.toml semver string matched the advisory windows; the engine should walk `Cargo.lock`.

**No prior published audit located.** Tensor's repository ships `SECURITY.md` with an email-disclosure path to `security@tensor.so` and does not publicly link a third-party audit report for the `marketplace` program. We searched public corpora and did not find a confirmable report URL. Per the constraint to not invent cross-references, the V12-style mapping table is omitted from this V1 deliverable. If Tensor confirms a published report later, V2 can add the table.

**Disposition.** This is a public-corpus pass with no engagement, but the deliverable ships a ready-to-apply remediation for `M-001`. `regression-tests/p001_cpi030_wns_program_pin.patch` adds `#[account(address = WNS_PROGRAM_ID)]` and `#[account(address = WNS_DISTRIBUTION_PROGRAM_ID)]` pins to the six WNS accounts structs and declares the canonical-id constants in `program/src/instructions/wns/mod.rs`. The patch was validated end-to-end against scan commit `8be7f2c`: it applies cleanly to a fresh checkout, passes `cargo check`, drops the CPI-030 finding count from 12 to 0 on rescan, and flips a Rust regression test (`regression-tests/cpi030_wns_pin_test/`) from FAIL (pre-patch) to PASS (post-patch). The full transcript is in `regression-tests/verification.log`. Final disposition (ship Option A as authored, swap to the handler-side `require_keys_eq!` idiom, or ACK the design) remains the Tensor team's call.

**Verification summary.** Pre-patch CPI-030 count: 12. Post-patch CPI-030 count: 0. Pre-patch unit test: FAIL (regression signal; the unpatched validator accepts a spoofed `wns_program` pubkey). Post-patch unit test: PASS (Anchor's `ConstraintAddress` error fires on the same spoofed pubkey across both pin sites; canonical IDs continue to pass). `cargo check -p marketplace-program`: clean both pre- and post-patch (47 unrelated cfg warnings against the workspace). The repo working tree was reverted to upstream HEAD after the verification loop; the audit pack applies cleanly to a fresh checkout.

### How this report is laid out

1. **Executive summary** — method, headline, layout (this section).
2. **Findings snapshot** — one-table view of `M-001`, `A-001`, `LC-001`, `LC-002`.
3. **Detailed Finding Records** — `M-001` (CPI-030 cluster, Medium) and `A-001` (QUAL-003 handler complexity, Advisory).
4. **Other Findings appendix** — lower-confidence groups (`LC-001` GOV-001 false positives; `LC-002` QUAL-003 codegen noise).
4c. **`cargo audit` supplement** — transitive CVE list against the current `Cargo.lock`.
5. **Workflow integration & delivery channels** — how this report fits into a remediation loop if Tensor wants one.
6. **Claudit** — agent-runnable companion epic at `claudit/`.

### Three views, one source of truth

You receive this audit as four artifacts, all derived from the same scan run against the same commit:

| Artifact | Audience | What it's for |
|---|---|---|
| `…TENSOR-MARKETPLACE-V1.pdf` | Humans | Executive narrative; what to read end-to-end. (Compile pending; see `README.md` for status.) |
| `…TENSOR-MARKETPLACE-V1.md` | Slack / email / PR descriptions | Same content as the PDF in plain Markdown. |
| `…TENSOR-MARKETPLACE-V1.yml` | Agents / CI / ticket import | Self-contained YAML keyed by finding ID, scan commit, severity, and confidence. |
| `…TENSOR-MARKETPLACE-V1.csv` | Spreadsheets / triage boards | Flat row-per-finding view (424 rows). |
| `…TENSOR-MARKETPLACE-V1.scan.json` | Engine / reproducibility | Raw SPECTRE output (13.78 MB). |

The `claudit/` directory holds the agent-runnable epic. The `regression-tests/` directory ships the prepared M-001 patch (`p001_cpi030_wns_program_pin.patch`), the standalone Rust regression-test crate (`cpi030_wns_pin_test/`), the post-patch SPECTRE JSON (`scan-post-patch.json`), and the end-to-end verification transcript (`verification.log`).

---

## 1. Findings — snapshot

| ID | Class | Rule | Sev | Conf. | Where | Disposition |
|---|---|---|---|---|---|---|
| `M-001` | Medium | CPI-030 ×12 | High | High | `program/src/lib.rs` (6 WNS handlers) plus their accounts structs in `program/src/instructions/wns/*.rs` | **PATCHABLE — patch shipped.** `regression-tests/p001_cpi030_wns_program_pin.patch` adds `#[account(address = WNS_PROGRAM_ID)]` and `#[account(address = WNS_DISTRIBUTION_PROGRAM_ID)]` pins across `BuyWns`, `BuyWnsSpl`, `DelistWns`, `TakeBidWns`, `ListWns`, `CloseExpiredListingWns`. Validated end-to-end: CPI-030 12 -> 0; regression test FAIL -> PASS; `cargo check` clean. |
| `A-001` | Advisory | QUAL-003 ×45 (hand-written) | Medium | Medium | `program/src/instructions/*.rs` and `program/src/{pnft_adapter,bubblegum_adapter,shared,state}.rs` | Audit-readiness refactor; top 3 hot handlers are `process_buy_core` (fan-out 294), `process_buy_core_spl` (293), `process_take_bid_legacy` / `process_buy_legacy_spl` (156–168). Schedule, do not patch. |
| `LC-001` | Lower-conf. | GOV-001 ×7 | High\* | Unlikely | `program/src/lib.rs` (7 user-owned instructions misclassified as admin) | Detector improvement on Pinpoint side. No code change in marketplace. |
| `LC-002` | Lower-conf. | QUAL-003 ×360 | Medium\* | Unlikely | `clients/rust/src/generated/*` (Codama / Kinobi auto-generated client code) | Suppress for generated files via path-prefix exclusion. No code change in marketplace. |

\* Severity is the rule's raw classification; confidence is our verified read.

---

## 2. Detailed Finding Records

### `PINPOINT-TENSORMARKETPLACE-M-001` — unconstrained WNS CPI program-account fields

| | |
|---|---|
| **Rule** | CPI-030 |
| **Severity** | Medium |
| **Confidence** | High |
| **Profile** | balanced |
| **Sites** | 12 (six handlers × two program fields each) |
| **Disposition** | **PATCHABLE — patch shipped at `regression-tests/p001_cpi030_wns_program_pin.patch`** |
| **Pre-patch CPI-030 count** | 12 |
| **Post-patch CPI-030 count** | 0 |
| **Unit test (pre-patch)** | FAIL (regression signal) |
| **Unit test (post-patch)** | PASS |

**Affected accounts structs** (all in `program/src/instructions/wns/`):

| Accounts struct | Defining file | `wns_program` line | `distribution_program` line | Anchor entrypoint line in `lib.rs` |
|---|---|---:|---:|---:|
| `BuyWns` | `wns/buy.rs` | 113 | 116 | 407 |
| `BuyWnsSpl` | `wns/buy_spl.rs` | 138 | (adjacent) | 414 |
| `DelistWns` | `wns/delist.rs` | 85 | (adjacent) | 427 |
| `TakeBidWns` | `wns/take_bid.rs` | 123 | (adjacent) | 441 |
| `ListWns` | `wns/list.rs` | 73 | (adjacent) | 431 |
| `CloseExpiredListingWns` | `wns/close_expired_listing.rs` | 77 | (adjacent) | 421 |

**Description.** Six WNS handler accounts structs include two program-typed fields, `wns_program` and `distribution_program`, both declared as `UncheckedAccount<'info>` with a `/// CHECK: checked on approve CPI` doc-comment and no `#[account(address = …)]` constraint. The handler bodies pass these account infos directly into the WNS `ApproveAccounts` CPI struct and then invoke into the program at the supplied address. There is no pubkey equality check in the handler before the invoke. Excerpt from `program/src/instructions/wns/buy.rs`:

```rust
/// CHECK: checked on approve CPI
pub wns_program: UncheckedAccount<'info>,

/// CHECK: checked on approve CPI
pub distribution_program: UncheckedAccount<'info>,
…
let approve_accounts = ApproveAccounts {
    …
    distribution_program: ctx.accounts.distribution_program.to_account_info(),
    wns_program: ctx.accounts.wns_program.to_account_info(),
    …
};
```

The two expected program IDs are pinned in the workspace metadata (`program/Cargo.toml` `program-dependencies`): `wns1gDLt8fgLcGhWi5MqAqgXpwEP1JftKE9eZnXS1HM` (WNS) and `diste3nXmK7ddDTs1zb6uday6j4etCa9RChD8fJ1xay` (distribution). Neither pin is propagated into the Anchor accounts struct as an `address = …` constraint, and the handler does not perform a `require_keys_eq!` against either constant before the CPI.

**Impact.** A transaction that supplies an attacker-controlled program in either field will cause the marketplace program to dispatch its CPI into attacker code at the same caller context. The Tensor team's documented mitigation, "checked on approve CPI", relies on the substituted program rejecting the call. That works against any honest target (including the real WNS program, which validates its inputs), but it leaves the program-id check fully off the marketplace side. A program that exists and accepts arbitrary CPI input (an attacker-deployed dummy) would not reject the call and could then perform whatever operations the supplied account list permits. The realistic attack surface is bounded by what the WNS `ApproveAccounts` accounts list grants the CPI target (a payer, mint, approve account, distribution account) and by the fact that the marketplace program does not sign for any PDA the WNS program needs. The risk is therefore "downstream-of-marketplace": a substituted `distribution_program` could short-circuit royalty distribution while still allowing the surrounding transaction to settle, depending on caller assumptions about WNS-side state mutations. We rate this Medium rather than High because the marketplace's own funds are not directly drainable via this substitution: the payer signs explicitly, the buyer authority is theirs, and the mint and list_state are validated. The risk is loss-of-integrity on the royalty enforcement path, not direct theft from the vault.

**Repair (recommended).**

Option A — declarative pin (preferred):

```rust
// program/src/instructions/wns/buy.rs (and the five sibling files)

#[account(address = wen_new_standard::ID)]
/// CHECK: program-id pinned via address constraint
pub wns_program: UncheckedAccount<'info>,

#[account(address = wns_distribution::ID)]
/// CHECK: program-id pinned via address constraint
pub distribution_program: UncheckedAccount<'info>,
```

This requires either a `pub const WNS_PROGRAM_ID: Pubkey = pubkey!("wns1gDLt8fgLcGhWi5MqAqgXpwEP1JftKE9eZnXS1HM")` in a shared module (Tensor already uses this pattern for `mpl_token_metadata::ID` and `mpl_token_auth_rules::ID` in `program/src/pnft_adapter.rs:88–97`) or a thin re-export from a `wen_new_standard` crate if one is added to `Cargo.toml`. The pnft_adapter pattern is the more idiomatic Tensor shape.

Option B — handler-side check:

```rust
// At the top of each process_*_wns handler:
require_keys_eq!(
    ctx.accounts.wns_program.key(),
    WNS_PROGRAM_ID,
    TcompError::BadProgramId
);
require_keys_eq!(
    ctx.accounts.distribution_program.key(),
    WNS_DISTRIBUTION_ID,
    TcompError::BadProgramId
);
```

Option A is preferred because it surfaces in the IDL (clients building transactions see the constraint), and Anchor will reject the transaction before the handler body runs.

**Disposition guidance.** The audit ships the Option A patch as
`regression-tests/p001_cpi030_wns_program_pin.patch`, validated end-to-end against `8be7f2c`. Tensor's team retains three options: apply the patch verbatim (recommended), swap to the Option B `require_keys_eq!` idiom (functionally equivalent, does not surface in the IDL), or ACK the design intent with a `SECURITY-NOTES.md`. The shipped patch is the strongest default; the validation evidence rules out a fourth path (apply-with-regression).

**Verification transcript (summary).** Against scan commit `8be7f2c` on 2026-05-11:

| Step | Command | Observed |
|---|---|---|
| Pre-state | `git status --porcelain && git rev-parse HEAD` | clean; 8be7f2c |
| Pre-patch compile | `cargo check -p marketplace-program` | OK |
| Pre-patch SPECTRE rescan | `pinpoint spectre scan . --profile balanced --min-confidence 0.78 --languages rust` | CPI-030 = 12 |
| Pre-patch unit test | `cargo test --manifest-path regression-tests/cpi030_wns_pin_test/Cargo.toml` | FAIL (spoofed wns_program accepted) |
| Apply | `git apply regression-tests/p001_cpi030_wns_program_pin.patch` | applied cleanly; 7 files changed |
| Post-patch compile | `cargo check -p marketplace-program` | OK |
| Post-patch SPECTRE rescan | (same command) | CPI-030 = 0 (full cluster suppressed) |
| Post-patch unit test | `cargo test --features patched ...` | PASS (ConstraintAddress fires on spoof) |
| Revert | `git checkout -- .` | working tree clean |

Full transcript with timestamps and exit codes in `regression-tests/verification.log`.

### `PINPOINT-TENSORMARKETPLACE-A-001` — high-fan-out instruction handlers (advisory; 45 sites)

| | |
|---|---|
| **Rule** | QUAL-003 |
| **Severity** | Medium |
| **Confidence** | Medium |
| **Profile** | balanced |
| **Disposition** | Audit-readiness; schedule, do not patch in same PR. |

The QUAL-003 detector flagged 405 functions with fan-out above 15 or fan-in above 20. Of those, **360 are in `clients/rust/src/generated/`** (the Codama/Kinobi-emitted Rust client crate) and are pure codegen noise, logged separately as `LC-002` below. The remaining **45 sites are in hand-written program code**, where fan-out is genuinely high on hot buy and take_bid handlers. The top sites are:

| Handler | File | Line | Fan-out |
|---|---|---:|---:|
| `process_buy_core` | `program/src/instructions/mpl_core/buy.rs` | 141 | 294 |
| `process_buy_core_spl` | `program/src/instructions/mpl_core/buy_spl.rs` | 201 | 293 |
| `pnft_adapter::From` impl | `program/src/pnft_adapter.rs` | 17 | 173 |
| `process_buy_legacy_spl` | `program/src/instructions/legacy/buy_spl.rs` | 258 | 156 |
| `process_buy_t22` | `program/src/instructions/token22/buy.rs` | 149 | 153 |
| `process_buy_legacy` | `program/src/instructions/legacy/buy.rs` | 202 | 153 |
| `close_bid_ta_ctx` | `program/src/instructions/legacy/take_bid.rs` | 211 | 148 |
| `process_bid` | `program/src/instructions/bid.rs` | 41 | 46 |
| `bubblegum_adapter::Into` | `program/src/bubblegum_adapter.rs` | 183 | 18 |
| `bubblegum_adapter::From` | `program/src/bubblegum_adapter.rs` | 24 | 16 |

The top six sites are the buy/take handler bodies that inline fee calc, royalty resolution, multi-program CPI (Bubblegum / Core / Metadata / Auth Rules / WNS / SPL Token / Token-2022), and state mutation in a single function. This is the same shape as the matariki-V1 `A-001` cluster: deep handlers turn a clean external audit into a long one. Suggested refactor pattern (one handler at a time):

```rust
pub fn process_buy_core<'info>(
    ctx: Context<'_, '_, '_, 'info, BuyCore<'info>>,
    max_amount: u64,
) -> Result<()> {
    let snapshot = validate_buy_core(&ctx, max_amount)?;
    let fees = calculate_buy_core_fees(&snapshot)?;
    execute_buy_core(ctx, snapshot, fees)
}
```

Tackle the top-2 hot handlers (`process_buy_core`, `process_buy_core_spl`) in the next-sprint refactor PR. Audit-readiness only; no correctness defect is implied.

---

## 4. Other Findings — appendix (lower-confidence)

Each row below was surfaced by a rule but disproved by source-level read. The remediation in every case is a detector improvement on Pinpoint's side, not a code change in `marketplace`.

### `LC-001` — GOV-001 false positives (7 sites; user-owned actions misclassified as admin-privileged)

The GOV-001 detector ("missing timelock on privileged instruction") flagged seven entrypoints in `program/src/lib.rs`. All seven are user-owned actions whose accounts struct gates the call on `has_one = owner` or `has_one = bidder` plus a `Signer<'info>`:

| Entrypoint | Line in `lib.rs` | Real authority | Defining accounts struct | Gating constraint (verified) |
|---|---:|---|---|---|
| `edit` | 57 | listing owner | `Edit` in `program/src/instructions/edit.rs:4` | `has_one = owner`, `owner: Signer<'info>` (lines 12, 15) |
| `cancel_bid` | 107 | bid owner | `CancelBid` in `program/src/instructions/cancel_bid.rs` | `has_one` constraint plus signer (same shape) |
| `delist` (compressed) | 217 | listing owner | `Delist` in `program/src/instructions/compressed/delist.rs` | same |
| `delist_legacy` | 311 | listing owner | `DelistLegacy` in `program/src/instructions/legacy/delist.rs` | same |
| `delist_t22` | 376 | listing owner | `DelistT22` in `program/src/instructions/token22/delist.rs` | same |
| `delist_wns` | 427 | listing owner | `DelistWns` in `program/src/instructions/wns/delist.rs` | same |
| `delist_core` | 470 | listing owner | `DelistCore` in `program/src/instructions/mpl_core/delist.rs` | same |

The detector pattern matched on "Anchor instruction mutates a state account that survives the call" and inferred admin context. The marketplace program has no admin role at all: there is no global config PDA, no `set_*` admin entrypoint, and the only authority that can mutate a `list_state` or `bid_state` is the wallet that created it. Suggesting a timelock on `edit` would prevent a seller from re-pricing their own listing within a block.

**Detector improvement (Pinpoint side).** GOV-001 should require either (a) a known admin-pattern accounts shape (`config: Account<…, Config>` plus `authority: Signer` matched against `config.admin`), or (b) the absence of any user-owned-state gating (`has_one`, `seeds = [user.key().as_ref(), …]`). Marketplace's user-owned model breaks both heuristics; the detector should defer to confidence demotion rather than flagging High.

### `LC-002` — QUAL-003 false positives in generated client code (360 sites)

360 of the 405 QUAL-003 findings sit in `clients/rust/src/generated/` — the Codama / Kinobi-emitted Rust client crate that the Tensor team regenerates from the IDL. The high fan-in on `default()`, `from()`, and `new()` reflects the codegen pattern (every instruction builder calls a shared `default()`), not handcrafted complexity. The accounts structs and builders are not handwritten and will be overwritten on every regen.

**Detector improvement (Pinpoint side).** Suppress QUAL-003 on files matching `clients/**/generated/**` and `**/generated/**`, or on files where the top-of-file marker `// This code was AUTOGENERATED using the codama library.` (or equivalent) is present. The Codama / Kinobi banner is a stable signal.

---

## 4c. `cargo audit` supplement

We ran `cargo audit --json` (database last-updated 2026-05-10) against `Cargo.lock` (269 packages). It reports **2 hard vulnerabilities** plus **13 warning-class advisories** (5 unmaintained, 6 unsound, 2 yanked). All 2 hard CVEs are transitive via the `solana-program 1.16.25` / `solana-sdk 1.16.25` chain; the `marketplace-program 0.7.1` crate does not depend on any of them directly.

### Hard vulnerabilities (2)

| Advisory | Package | Lockfile version | Patched in | Title |
|---|---|---|---|---|
| RUSTSEC-2024-0344 | curve25519-dalek | 3.2.1 | `>=4.1.3` | Timing variability in `Scalar29::sub`/`Scalar52::sub` |
| RUSTSEC-2022-0093 | ed25519-dalek | 1.0.1 | `>=2` | Double Public Key Signing Function Oracle Attack |

### Warning-class advisories (13)

Unmaintained (5): `atty 0.2.14`, `bincode 1.3.3`, `derivative 2.2.0`, `libsecp256k1 0.6.0`, `paste 1.0.14`.
Unsound (6): `atty 0.2.14` (RUSTSEC-2021-0145), `borsh 0.9.3` and `borsh 0.10.3` (RUSTSEC-2023-0033), `keccak 0.1.5` (RUSTSEC-2026-0012), `rand 0.7.3` and `rand 0.8.5` (RUSTSEC-2026-0097).
Yanked (2): `bytemuck 1.14.3`, `keccak 0.1.5`.

**Recommended action.** Track `solana-*` SDK upgrade cadence; revisit `cargo audit` on each `solana-*` bump. The hard CVEs resolve when `solana-program` updates its `curve25519-dalek` and `ed25519-dalek` pins (Solana 2.x already does for some downstream targets). For workspace hygiene, an explicit `[workspace.dependencies]` override or a `deny.toml` with `RUSTSEC-*` ignore entries (documenting the transitive-via-solana rationale) keeps developer terminals quiet without hiding the warning state.

**Detector improvement on Pinpoint side.** Same gap recorded for matariki: `DEPVULN-001` should walk `Cargo.lock` rather than matching `Cargo.toml` semver strings. Tensor's `Cargo.toml` does not declare any of the affected packages directly, so the detector reports zero `DEPVULN-001` sites on this scan and silently misses both transitive CVEs.

---

## 5. Workflow integration & delivery channels

### The audit loop, applied to a corpus pass

This pack is a public-corpus deliverable. Tensor was not engaged for this work and may receive it cold via the `security@tensor.so` disclosure channel listed in `SECURITY.md`. If the team wants to act on `M-001`, the loop is the same as any Pinpoint engagement:

1. **Audit.** The four artifacts above (`.pdf` / `.md` / `.yml` / `.csv`) plus `claudit/` plus `regression-tests/` (prepared patch, regression test, post-patch scan JSON, verification log).
2. **Feed.** Drop the `.yml` into an LLM (Claude / Cursor / Codex) or Pinpoint's MCP server; each finding is self-contained.
3. **Apply or decide on M-001.** Default action: `git apply regression-tests/p001_cpi030_wns_program_pin.patch`. Alternates: swap to the handler-side `require_keys_eq!` idiom, or write a SECURITY-NOTES.md ACK.
4. **Commit.** Tag with the audit-trail trailers:

   ```
   Pinpoint-Finding: PINPOINT-TENSORMARKETPLACE-M-001          # if patched
   Pinpoint-Finding-Acknowledged: PINPOINT-TENSORMARKETPLACE-M-001  # if ACK
   Pinpoint-Scan-Commit: 8be7f2c3d60c18871e0913b5f837408eeb69047d
   ```

5. **Re-audit.** Run `pinpoint spectre scan` against the remediation commit. CPI-030 count should drop 12 to 0 if patched; remain 12 if ACK. The audit already captured the patched-state scan JSON at `regression-tests/scan-post-patch.json` for byte-level comparison.

### Naming & versioning

Every Pinpoint deliverable follows `YYMMDD-SPECTRE-AUDIT-CUSTOMER-PROJECT-Vn`. This is V1 of the public-corpus scan. Re-audits ship as V2, V3, ….

### Suggested order of work, if Tensor wants to act

1. **One small PR — the WNS program-id pins.** ~24 LoC across six files; surfaces in the IDL; no behaviour change for honest callers.
2. **Next sprint — A-001 handler refactor.** Tackle `process_buy_core` and `process_buy_core_spl` first; helper extraction sketched above. Audit-readiness, not security.
3. **Pinpoint-side, parallel.** Detector improvements for `LC-001` (GOV-001 admin heuristic) and `LC-002` (QUAL-003 path-prefix suppression for generated code) land in the next engine release; on V2 of this audit they will not surface.

---

## 6. Claudit — the agent-runnable companion epic

The remediation workflow above is also packaged as a SPOQ-style task graph at `claudit/`. Wave 0 captures the `cargo audit` baseline and asserts repo state; Wave 1 reviews and applies the prepared M-001 patch (or swaps idiom / ACKs); Wave 2 rescans after the patch lands and opens follow-up tickets for the advisory refactor.

### Wave structure

| Wave | Tasks | Purpose |
|---|---|---|
| Wave 0 | 01 cargo-audit-baseline · 02 git-state-check | Pre-flight: capture baseline, assert HEAD is `8be7f2c`. |
| Wave 1 | 03 m001-review-prepared-patch · 04 m001-apply-pin · 05 commit-with-pinpoint-trailers | Review the shipped patch with the operator (apply-as-is / swap-idiom / ACK), apply, audit-trail commit. |
| Wave 2 | 06 rescan-with-spectre · 07 a001-buy-core-refactor-ticket · 08 detector-improvement-feedback | Re-audit and follow-up tickets. |

The epic halts at task 03 if no operator confirms which disposition to take. Default recommendation: apply the shipped patch verbatim.

---

Reply via the `security@tensor.so` disclosure channel listed in Tensor's `SECURITY.md` if the team wants to coordinate on the M-001 disposition or open a paid follow-up audit. Otherwise this V1 deliverable is archived against scan commit `8be7f2c` for the public-corpus record.
