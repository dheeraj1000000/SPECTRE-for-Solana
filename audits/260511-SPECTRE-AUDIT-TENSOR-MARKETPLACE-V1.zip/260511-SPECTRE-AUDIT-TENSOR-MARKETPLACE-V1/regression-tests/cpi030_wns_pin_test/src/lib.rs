//! CPI-030 remediation harness for the Tensor marketplace WNS handler surface.
//!
//! See `Cargo.toml` for the scope statement. This crate isolates the
//! `#[account(address = WNS_PROGRAM_ID)]` constraint pattern the audit
//! patch introduces and verifies it actually rejects a forged program id.
//!
//! Anchor's `#[account(address = X)]` constraint expands (at the relevant
//! line in `anchor-lang-0.29.0/src/accounts/macros.rs`) to:
//!
//! ```ignore
//! if account.key() != &expected_key {
//!     return Err(anchor_lang::error::Error::from(
//!         anchor_lang::error::ErrorCode::ConstraintAddress,
//!     ));
//! }
//! ```
//!
//! We replicate that contract here directly so the harness is small,
//! deterministic, and free of `solana-program-test` scaffolding. The
//! unpatched function intentionally skips the check, which mirrors the
//! pre-patch source of `wns_program: UncheckedAccount<'info>` with no
//! `#[account(address = ...)]` attribute.

use anchor_lang::error::ErrorCode;
use anchor_lang::prelude::Pubkey;

/// Canonical mainnet program id for the WNS (Wen New Standard) program.
/// Source of truth: tensor-foundation/marketplace
/// `program/Cargo.toml` `package.metadata.solana.program-dependencies` and
/// `clients/rust/src/generated/instructions/buy_wns.rs` default account
/// values.
pub const WNS_PROGRAM_ID: Pubkey = Pubkey::new_from_array([
    14, 9, 56, 103, 39, 71, 245, 151, 225, 11, 12, 66, 119, 20, 22, 254, 125, 49, 58, 181, 187,
    140, 169, 88, 174, 154, 34, 151, 209, 118, 77, 28,
]);

/// Canonical mainnet program id for the WNS distribution program.
/// Source of truth: same as above.
pub const WNS_DISTRIBUTION_PROGRAM_ID: Pubkey = Pubkey::new_from_array([
    9, 104, 66, 148, 82, 221, 22, 144, 27, 115, 58, 193, 53, 173, 221, 183, 255, 121, 233, 152,
    109, 170, 158, 38, 122, 4, 71, 236, 34, 107, 141, 254,
]);

/// Pre-patch (UNPATCHED) shape: the field is `UncheckedAccount` with no
/// `#[account(address = ...)]` constraint, so validation is a no-op and
/// the caller may pass any pubkey for `wns_program`.
pub fn validate_wns_program_unpatched(_supplied_wns_program: &Pubkey) -> Result<(), ErrorCode> {
    // Pre-patch: no check. Mirrors the `pub wns_program: UncheckedAccount<'info>`
    // declaration with only the doc-comment `/// CHECK: checked on approve CPI`
    // (the downstream WNS CPI never actually verifies the program id pre-flight,
    // which is the substance of M-001).
    Ok(())
}

/// Post-patch (PATCHED) shape: equivalent to the macro expansion of
/// `#[account(address = super::WNS_PROGRAM_ID)]`.
pub fn validate_wns_program_patched(supplied_wns_program: &Pubkey) -> Result<(), ErrorCode> {
    if supplied_wns_program != &WNS_PROGRAM_ID {
        return Err(ErrorCode::ConstraintAddress);
    }
    Ok(())
}

/// Same idiom applied to `distribution_program`.
pub fn validate_distribution_program_patched(
    supplied_distribution_program: &Pubkey,
) -> Result<(), ErrorCode> {
    if supplied_distribution_program != &WNS_DISTRIBUTION_PROGRAM_ID {
        return Err(ErrorCode::ConstraintAddress);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A program id chosen by an attacker. Any pubkey that is not the
    /// canonical WNS program id works; we use an all-`0xAA` sentinel for
    /// clarity in the test transcript.
    fn spoofed_program_id() -> Pubkey {
        Pubkey::new_from_array([0xAA; 32])
    }

    /// The single test we run in both pre-patch and post-patch states.
    ///
    /// Pre-patch (no `--features patched`): we only exercise the unpatched
    /// validator and assert it rejects the spoof. It doesn't — so the test
    /// fails, exactly as a regression test for M-001 should.
    ///
    /// Post-patch (`--features patched`): we exercise the patched
    /// validator and assert it rejects the spoof. It does — test passes.
    #[test]
    fn wns_program_pin_rejects_spoofed_program_id() {
        let spoof = spoofed_program_id();

        // Sanity: canonical IDs should never accidentally equal the spoof.
        assert_ne!(WNS_PROGRAM_ID, spoof);
        assert_ne!(WNS_DISTRIBUTION_PROGRAM_ID, spoof);

        #[cfg(not(feature = "patched"))]
        {
            // Pre-patch behaviour. The unpatched validator must reject the
            // spoof for the assertion to pass; it doesn't, so the test
            // fails on base. That failure IS the regression signal.
            let result = validate_wns_program_unpatched(&spoof);
            assert!(
                result.is_err(),
                "M-001 regression: pre-patch handler accepted a spoofed wns_program id \
                 (CPI-030). Apply p001_cpi030_wns_program_pin.patch and re-run with \
                 `--features patched`."
            );
        }

        #[cfg(feature = "patched")]
        {
            // Post-patch behaviour. Both pinning sites must reject the spoof.
            let wns_err = validate_wns_program_patched(&spoof)
                .expect_err("patched handler must reject spoofed wns_program");
            assert!(matches!(wns_err, ErrorCode::ConstraintAddress));

            let dist_err = validate_distribution_program_patched(&spoof).expect_err(
                "patched handler must reject spoofed distribution_program",
            );
            assert!(matches!(dist_err, ErrorCode::ConstraintAddress));

            // Canonical IDs continue to pass.
            assert!(validate_wns_program_patched(&WNS_PROGRAM_ID).is_ok());
            assert!(
                validate_distribution_program_patched(&WNS_DISTRIBUTION_PROGRAM_ID).is_ok()
            );
        }
    }
}
