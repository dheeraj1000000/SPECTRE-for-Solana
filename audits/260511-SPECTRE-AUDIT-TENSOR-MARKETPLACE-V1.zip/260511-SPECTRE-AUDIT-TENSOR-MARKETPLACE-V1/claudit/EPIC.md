# Epic: claudit-tensor-marketplace-v1

**Audit:** `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1`
**Repo:** `tensor-foundation/marketplace` @ commit `8be7f2c3d60c18871e0913b5f837408eeb69047d`
**Owner:** Tensor Foundation (public-corpus pass; no engagement)
**Engagement type:** SPECTRE V1 corpus scan + disposition-driven remediation loop

---

## Vision and overview

The 2026-05-11 SPECTRE pass against `tensor-foundation/marketplace` surfaced
424 raw findings at the `balanced` profile (min-confidence 0.78). The
disproval pass narrowed these to:

- **1 Medium cluster** (`M-001`, CPI-030 ×12) on the WNS handler surface
  (`wns_program` and `distribution_program` declared as `UncheckedAccount`
  with no `#[account(address = …)]` constraint across six accounts structs).
- **1 Advisory cluster** (`A-001`, QUAL-003 ×45 on handwritten code).
  Audit-readiness, not security.
- **2 lower-confidence groups** (LC-001 GOV-001 ×7 user-owned actions
  misclassified as admin; LC-002 QUAL-003 ×360 on auto-generated Codama
  client code).

Plus a bidirectional finding: `cargo audit` against `Cargo.lock` reports 2
hard CVEs (curve25519-dalek, ed25519-dalek; both transitive via
`solana-program 1.16.25`) plus 13 warning-class advisories.

**This epic is shaped for a corpus pass, not an engaged-customer flow.**
Wave 1 is intentionally a halt-on-decision pattern: task 03 surfaces the
M-001 disposition (pin vs ACK) to a human operator and does NOT
speculatively patch. The team (or anyone choosing to act on this audit)
decides; the agent then applies the chosen disposition in task 04 and
commits in task 05.

Wave 0 is substantive (it captures the cargo audit baseline and anchors
repo state). Wave 2 is substantive (rescan + ticket creation for the
advisory and detector-improvement feedback). Wave 1 is the only deferred
phase, and it defers cleanly on a documented decision boundary.

---

## Architecture

```
+--------------------------------------------------------------------------------+
|         CLAUDIT REMEDIATION LOOP — tensor-marketplace V1 (corpus pass)         |
+--------------------------------------------------------------------------------+
|                                                                                |
|   +---------------------+      +---------------------------+                   |
|   |  Audit deliverable  |      |  Tensor public repo        |                  |
|   |  (this directory)   |      |  marketplace @ 8be7f2c     |                  |
|   |  - findings YAML    |----->|  program/src/instructions/ |                  |
|   |  - pin patch sketch |      |  program/Cargo.toml        |                  |
|   |  - ACK text         |      |                            |                  |
|   +----------+----------+      +-----------+----------------+                  |
|              |                             |                                   |
|              v                             v                                   |
|   +--------------------------------------------------------+                   |
|   |  Wave 0: Pre-flight                                    |                   |
|   |  01 cargo-audit-baseline (capture 2 hard + 13 warns)   |                   |
|   |  02 git-state-check (assert HEAD == 8be7f2c)           |                   |
|   +-------------------------+------------------------------+                   |
|                             |                                                  |
|                             v                                                  |
|   +--------------------------------------------------------+                   |
|   |  Wave 1: M-001 disposition + apply + commit            |                   |
|   |  03 m001-disposition-decision    [HALT-ON-DECISION]    |                   |
|   |  04 m001-apply-pin-or-ack        (after decision)      |                   |
|   |  05 commit-with-pinpoint-trailers                      |                   |
|   +-------------------------+------------------------------+                   |
|                             |                                                  |
|                             v                                                  |
|   +--------------------------------------------------------+                   |
|   |  Wave 2: Re-audit + follow-up tickets                  |                   |
|   |  06 rescan-with-spectre (CPI-030 12 -> 0 if pin)       |                   |
|   |  07 a001-buy-core-refactor-ticket (ticket only)        |                   |
|   |  08 detector-improvement-feedback (engine side)        |                   |
|   +--------------------------------------------------------+                   |
|                                                                                |
+--------------------------------------------------------------------------------+
```

---

## Components

### 1. Pre-flight (Wave 0, tasks 01 + 02)

- **01 cargo-audit-baseline.** Runs `cargo audit --json` and confirms the
  2 hard CVEs and 13 warning advisories still match the YAML supplement.
  Archives output for the rescan-comparison phase.
- **02 git-state-check.** Asserts `git rev-parse HEAD == 8be7f2c`. The
  M-001 patch sketch in the YAML uses line numbers derived from this
  commit; line drift on a different HEAD breaks the patch apply.

### 2. M-001 disposition decision (Wave 1, task 03) — HALT-ON-DECISION

Task 03 surfaces the M-001 finding (CPI-030 cluster on the WNS handler
surface) to a human operator and requests one of three responses:

- `PIN_OPTION_A` — apply the `#[account(address = WNS_PROGRAM_ID)]` and
  `#[account(address = WNS_DISTRIBUTION_ID)]` constraints across the six
  WNS accounts structs (preferred; surfaces in the IDL).
- `PIN_OPTION_B` — apply the `require_keys_eq!` checks at the top of each
  `process_*_wns` handler (functionally equivalent; no IDL surface).
- `ACK` — write the documented SECURITY-NOTES.md text confirming the
  "checked on approve CPI" design is intentional.

The agent does NOT speculate. If no human decision is supplied, task 03
halts and reports the choice to the operator.

### 3. Apply disposition (Wave 1, task 04)

Based on task 03's decision:

- If `PIN_OPTION_A` or `PIN_OPTION_B`: applies the constructed patch across
  the six WNS files. Runs `cargo build --release -p marketplace-program`
  to verify the patched source compiles.
- If `ACK`: appends the documented text to `SECURITY-NOTES.md` (creating
  the file if absent; Tensor's repo does not currently ship one).

### 4. Audit-trail commit (Wave 1, task 05)

Single commit with the appropriate trailers:

- If patched:
  ```
  Pinpoint-Finding: PINPOINT-TENSORMARKETPLACE-M-001
  Pinpoint-Scan-Commit: 8be7f2c3d60c18871e0913b5f837408eeb69047d
  ```
- If ACK:
  ```
  Pinpoint-Finding-Acknowledged: PINPOINT-TENSORMARKETPLACE-M-001
  Pinpoint-Scan-Commit: 8be7f2c3d60c18871e0913b5f837408eeb69047d
  ```

### 5. Re-audit (Wave 2, task 06)

Runs `pinpoint spectre scan . --local --output json --profile balanced --min-confidence 0.78 --languages rust` against the remediation commit. Expected:

- If patched: `CPI-030` count drops 12 → 0; `GOV-001` and `QUAL-003`
  counts unchanged.
- If ACK: all counts unchanged; the audit-trail trailer closes the
  finding.

### 6. Follow-up tickets (Wave 2, tasks 07 + 08)

- **07 a001-buy-core-refactor-ticket.** Opens a tracker ticket for the
  top-2 hot handlers (`process_buy_core`, `process_buy_core_spl`).
  Includes the helper-extraction sketch. Does NOT implement.
- **08 detector-improvement-feedback.** Logs three engine-side detector
  improvements with the Pinpoint engine team:
  - `GOV-001` admin-pattern heuristic (LC-001 root cause).
  - `QUAL-003` path-prefix suppression for `**/generated/**` (LC-002).
  - `DEPVULN-001` walking `Cargo.lock` not `Cargo.toml` (cargo-audit gap).

---

## Waves

### Wave 0 — Pre-flight (~3 min)

| Task | Title | Depends on |
|------|-------|------------|
| 01 | cargo-audit-baseline | (none) |
| 02 | git-state-check | (none) |

Tasks 01 and 02 are independent; they may run in parallel.

### Wave 1 — M-001 disposition + apply + commit (variable; halt-on-decision)

| Task | Title | Depends on |
|------|-------|------------|
| 03 | m001-disposition-decision | 02 |
| 04 | m001-apply-pin-or-ack | 03 |
| 05 | commit-with-pinpoint-trailers | 04 |

Wave 1 is serial. Task 03 halts on missing-decision; the wall-clock time
to complete depends entirely on operator response.

### Wave 2 — Re-audit + follow-up tickets (~3 min)

| Task | Title | Depends on |
|------|-------|------------|
| 06 | rescan-with-spectre | 05 |
| 07 | a001-buy-core-refactor-ticket | (none; opens a ticket only) |
| 08 | detector-improvement-feedback | (none; logs to Pinpoint engine team) |

---

## Success Criteria

- [ ] Wave 0 pre-flight passes (HEAD at `8be7f2c`, working tree clean).
- [ ] Wave 1 task 03 produces a recorded disposition (`PIN_OPTION_A`,
  `PIN_OPTION_B`, or `ACK`).
- [ ] Wave 1 task 04 either applies the patch and `cargo build` is green,
  or appends the SECURITY-NOTES.md text and the file commits cleanly.
- [ ] Wave 1 task 05 lands a single commit on a feature branch (recommended:
  `feat/spectre-v1-cpi030-pin` or `docs/spectre-v1-cpi030-ack`).
- [ ] Commit message carries the appropriate Pinpoint-* trailers.
- [ ] Wave 2 task 06 rescan shows the expected `CPI-030` count (0 if
  patched; 12 if ACK).
- [ ] Tasks 07 and 08 produce one tracker entry each.

---

## Task Dependencies

```
Phase 0 (pre-flight, parallel):
  01 cargo-audit-baseline      (no deps)
  02 git-state-check           (no deps)

Phase 1 (M-001 disposition, serial):
  03 m001-disposition-decision (deps: 02; HALT-ON-DECISION)
  04 m001-apply-pin-or-ack     (deps: 03)
  05 commit-with-pinpoint-trailers (deps: 04)

Phase 2 (re-audit; depends on the commit):
  06 rescan-with-spectre       (deps: 05)

Phase 3 (follow-up; independent of remediation):
  07 a001-buy-core-refactor-ticket   (no deps; ticket only)
  08 detector-improvement-feedback   (no deps; engine-side feedback)
```

Critical path: 02 → 03 (operator wait) → 04 → 05 → 06. Tasks 01, 07, 08
parallelise off this path.

---

## Dispatch Strategy

Single-agent dispatch is the default. One Claude session walks tasks 01 →
06 in order, halting at task 03 for the operator's disposition decision.
Tasks 07 and 08 can dispatch to a tracker-API agent or engine-feedback
channel in parallel with phase 2.

Recommended tooling per phase:

| Phase | Agent role | Tools needed |
|------:|------------|--------------|
| 0     | shell + jq | `cargo audit`, `git`, `jq` |
| 1.3   | conversation | none (decision elicitation) |
| 1.4   | git + rust | `git apply` or file edit; `cargo build` |
| 1.5   | git | `git commit` with heredoc trailers |
| 2     | shell + jq | `pinpoint spectre scan`, `jq` |
| 3     | tracker API / messaging | Linear / Jira / GitHub Issues / Pinpoint engine queue |

Halt-on-failure policy applies throughout. Task 03 also halts on
halt-on-decision: if the operator does not supply a disposition, the agent
surfaces the three options and stops cleanly without speculative work.

---

## Risks

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| Working tree not at `8be7f2c` (line drift in patch) | High — pin patch fails to apply, manual fixup required | Low | Task 02 asserts `git rev-parse HEAD == 8be7f2c`; halts if not. Patch line numbers are anchored to this commit. |
| Operator supplies no disposition | Low — Wave 1 halts cleanly at task 03 | Medium | Task 03 is explicitly halt-on-decision; the agent surfaces the three options and stops without speculative work. This is the intended path for a corpus pass. |
| `wen_new_standard` / `wns_distribution` crate not available at the right version for `address = …` constraint | Medium — Option A patch needs a shared constant module instead of a re-export | Medium | Task 04 detects this and falls back to either (a) `const WNS_PROGRAM_ID: Pubkey = pubkey!("wns1gDLt8…")` in a shared module (matching Tensor's pnft_adapter.rs pattern), or (b) Option B `require_keys_eq!`. Both are functionally equivalent on-chain. |
| Hidden pre-commit hooks reject the trailers | Medium — Wave 1 cannot land cleanly | Low | Task 05 forbids `--no-verify`. If hooks fail, the agent surfaces them and lets the operator decide. |
| Re-audit (task 06) runs against the wrong commit | Medium — false report | Low | Task 06 asserts `HEAD ≠ 8be7f2c` and reads the commit trailer to confirm the audit chain. |
| Tensor team is not contacted for disposition | Low — V1 sits as a corpus artifact | Medium | This is the default state. The corpus pass is published either way; coordinating with `security@tensor.so` is a separate step outside this epic's scope. |
| Detector-improvement feedback (task 08) is not actionable in Pinpoint's current sprint | Low — feedback queued, not implemented | Medium | Task 08 deposits a structured engine-side note rather than blocking on implementation. Detector fixes ship in a future engine release; V2 of this audit will surface the improvements. |

## Out of scope

- The 2 hard `cargo audit` CVEs (`curve25519-dalek 3.2.1`,
  `ed25519-dalek 1.0.1`). Both are transitive via `solana-program 1.16.25`
  and resolve when `solana-program` updates its dep pins. The marketplace
  workspace can document the rationale in a `deny.toml` if it wants
  quieter terminals; not in this epic's scope.
- The 13 warning-class advisories (unmaintained / unsound / yanked). Same
  upstream-driven shape.
- The 360 generated-client-code `QUAL-003` sites (LC-002). Detector-side
  fix; tracked in task 08.
- The 7 `GOV-001` false positives (LC-001). Detector-side fix; tracked in
  task 08.
- The `A-001` advisory refactor. Task 07 opens a ticket; implementation is
  a separate next-sprint PR for the Tensor team.

---

## Confidence and rehearsal record

Read-only audit. Unlike the matariki-V1 deliverable (which rehearsed the
full apply / cargo-check / rescan / revert loop end-to-end), this V1 corpus
pass is shipped without an end-to-end rehearsal because:

- No patch ships in V1 (M-001 is a halt-on-decision finding).
- The patch sketch in the YAML is a 6-file, 12-line constraint addition
  whose line numbers are anchored against `8be7f2c`; it applies mechanically
  once the disposition is confirmed.
- The `cargo audit --json` baseline was run and captured (2 hard CVEs + 13
  warnings); the YAML supplement reflects exactly that.
- The source read-through verified each M-001 site (the `wns_program` /
  `distribution_program` declarations in the six handler files) and each
  LC-001 site (the `has_one = owner` + `Signer<'info>` gating in the
  corresponding instruction handlers).

If a V2 ships after a Tensor disposition lands, V2 will carry the full
end-to-end rehearsal log against the remediation commit, matching the
matariki-V1 format.
