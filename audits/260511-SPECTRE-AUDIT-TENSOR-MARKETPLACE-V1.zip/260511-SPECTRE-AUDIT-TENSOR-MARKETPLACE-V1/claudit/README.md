# `claudit` — Claude-driven audit remediation loop (Tensor Marketplace V1)

This directory packages the audit findings, the M-001 patch sketch, the
ACK text, and a SPOQ-style task graph so an LLM agent (or a human) can run
the **audit → disposition → apply → commit → rescan** loop end-to-end. It
is shaped for a public-corpus posture: Wave 1 halts on a human disposition
decision rather than auto-patching.

Hand the audit project to Claude and say:

> *"Run claudit on `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1`."*

Claude reads this README, loads the YAML, and works the tasks in
`claudit/tasks/` in dependency order. By the end (assuming a disposition
is supplied), the Tensor marketplace repo will have either:

- The 12-site, ~24-LoC `address = …` constraint applied across the six WNS
  handler accounts structs; `cargo build` clean; the rescan reports
  `CPI-030 = 0`; the commit carries `Pinpoint-Finding: PINPOINT-TENSORMARKETPLACE-M-001`. **OR**
- A new `SECURITY-NOTES.md` documenting the "checked on approve CPI"
  design as an intentional ACK; the commit carries
  `Pinpoint-Finding-Acknowledged: PINPOINT-TENSORMARKETPLACE-M-001`.

---

## What is "claudit"?

A `claudit` is the agent-runnable companion to a static audit report. The
SPECTRE PDF / MD / CSV are for humans; the YAML is for LLMs; this directory
is the **execution plan** which is a small SPOQ-flavoured task graph that
ties everything together.

```
claudit/
├── README.md                                 ← you are here
├── EPIC.md                                   ← architecture, waves, dependency diagram
└── tasks/
    ├── 01-cargo-audit-baseline.yml           (Wave 0 pre-flight)
    ├── 02-git-state-check.yml                (Wave 0 pre-flight)
    ├── 03-m001-disposition-decision.yml      (Wave 1; HALT-ON-DECISION)
    ├── 04-m001-apply-pin-or-ack.yml          (Wave 1 apply)
    ├── 05-commit-with-pinpoint-trailers.yml  (Wave 1 commit)
    ├── 06-rescan-with-spectre.yml            (Wave 2 verify)
    ├── 07-a001-buy-core-refactor-ticket.yml  (Wave 2 follow-up)
    └── 08-detector-improvement-feedback.yml  (Wave 2 follow-up)
```

---

## Pre-flight

```bash
cargo install cargo-audit
# Solana SBF toolchain not strictly required unless the operator chooses
# PIN_OPTION_A or PIN_OPTION_B; in those cases, `cargo build --release -p
# marketplace-program` is sufficient (no need for `anchor build`).
```

---

## Running the loop

### Option A — autonomous (recommended)

Hand Claude the audit project and the prompt:

> *Read `claudit/README.md` and `claudit/EPIC.md`. Then execute every task
> in `claudit/tasks/` in dependency order, halting on first failure. Note
> that task 03 is HALT-ON-DECISION: surface the M-001 disposition options
> to the operator and stop. Do NOT speculatively patch.*

Claude works through tasks 01 → 02, halts at task 03 for the operator's
disposition, then resumes tasks 04 → 06 once the decision is supplied.
Tasks 07 + 08 dispatch as follow-ups.

### Option B — step-by-step

```bash
# Wave 0: pre-flight
claude run claudit/tasks/01-cargo-audit-baseline.yml
claude run claudit/tasks/02-git-state-check.yml

# Wave 1: M-001 disposition + apply + commit
claude run claudit/tasks/03-m001-disposition-decision.yml      # halts; operator chooses
claude run claudit/tasks/04-m001-apply-pin-or-ack.yml          # applies the chosen path
claude run claudit/tasks/05-commit-with-pinpoint-trailers.yml  # single audit-trail commit

# Wave 2: re-scan and follow-up tickets
claude run claudit/tasks/06-rescan-with-spectre.yml
claude run claudit/tasks/07-a001-buy-core-refactor-ticket.yml  # opens ticket; does not implement
claude run claudit/tasks/08-detector-improvement-feedback.yml  # engine-side feedback
```

### Option C — human-driven, agent-assisted

You make the disposition call yourself; ask Claude only for the patch
construction or SECURITY-NOTES.md drafting and the verification rescan.

---

## How tasks reference the YAML

Each task points back to specific keys in
`260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.yml` rather than duplicating
content. Example from `04-m001-apply-pin-or-ack.yml`:

```yaml
inputs:
  patch_source_option_a: yaml.medium_findings[0].proposed_remediation_pin_option_a
  patch_source_option_b: yaml.medium_findings[0].proposed_remediation_pin_option_b
  ack_text:              yaml.medium_findings[0].proposed_disposition_ack_text
  expected_files_changed_if_pin:
    - program/src/instructions/wns/buy.rs
    - program/src/instructions/wns/buy_spl.rs
    - program/src/instructions/wns/delist.rs
    - program/src/instructions/wns/take_bid.rs
    - program/src/instructions/wns/list.rs
    - program/src/instructions/wns/close_expired_listing.rs
```

---

## Closing the loop

After task 06 passes, the remediation commit will carry the audit-trail
trailers set in task 05. When you ship V2 of this audit
(`260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V2`) against the remediation
commit, the trailer chain auto-marks `M-001` as either `remedied` or
`acknowledged-on-V1` in the audit history.

---

## Confidence

Read-only audit (no patch shipped in V1; see `EPIC.md` "Confidence and
rehearsal record"). The patch sketch in the YAML applies mechanically at
the documented line numbers anchored against `8be7f2c`. The `cargo audit`
baseline is captured as-run.
