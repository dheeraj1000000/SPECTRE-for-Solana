# 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1

**Customer:** Tensor Foundation (public-corpus pass; no engagement) &nbsp;·&nbsp; **Project:** `marketplace`
**Scan commit:** `8be7f2c3d60c18871e0913b5f837408eeb69047d` &nbsp;·&nbsp; **Engine:** Pinpoint SPECTRE v0.1.0
**Date:** 2026-05-11 &nbsp;·&nbsp; **Version:** V1

---

## What this is

This directory is a complete SPECTRE audit deliverable for a public-corpus
pass against `tensor-foundation/marketplace`. Tensor was not engaged for this
work; the deliverable is read-only and ships against the public HEAD at
`8be7f2c`. Everything you need to **read the audit, decide the M-001
disposition, and re-verify** is in here. No external fetches.

**Outcome:**

- **0 Critical** on read-through.
- **1 Medium cluster** (`M-001`, CPI-030 ×12) on the WNS handler surface: six accounts structs (`BuyWns`, `BuyWnsSpl`, `DelistWns`, `TakeBidWns`, `ListWns`, `CloseExpiredListingWns`) declare `wns_program` and `distribution_program` as `UncheckedAccount` with no `#[account(address = …)]` constraint. **Patch shipped and validated end-to-end** at `regression-tests/p001_cpi030_wns_program_pin.patch`: applies cleanly to upstream HEAD `8be7f2c`, drops the CPI-030 count from 12 to 0 on rescan, flips the bundled Rust regression test from FAIL (pre-patch) to PASS (post-patch). Tensor team retains final disposition (apply Option A as authored, swap to handler-side `require_keys_eq!`, or ACK with SECURITY-NOTES.md).
- **1 Advisory cluster** (`A-001`, QUAL-003 ×45 hand-written) on hot buy/take_bid handlers. Audit-readiness, not security; top sites are `process_buy_core` (fan-out 294), `process_buy_core_spl` (293), `pnft_adapter::From` (173).
- **2 Lower-confidence groups:**
  - `LC-001` — GOV-001 ×7 all false positives. The detector misclassified user-owned actions (`edit`, `delist*`, `cancel_bid`, all gated by `has_one = owner` + `Signer`) as admin-privileged. The marketplace program has no admin role.
  - `LC-002` — QUAL-003 ×360 in `clients/rust/src/generated/` (Codama / Kinobi codegen output); pure detector noise on auto-generated code.
- **Prior audit cross-check:** No published third-party report for `tensor-foundation/marketplace` could be confirmed; cross-reference table omitted per the "do not invent cross-refs" constraint.
- **Bidirectional finding:** `cargo audit` against the workspace `Cargo.lock` (269 packages) reports **2 hard CVEs** (`curve25519-dalek 3.2.1`, `ed25519-dalek 1.0.1`; both transitive via `solana-program 1.16.25`) plus 13 warning-class advisories. SPECTRE's `DEPVULN-001` reported zero sites on this scan; same engine-side gap as the matariki deliverable.

## Reading order

If you want to **understand what we found** → start with the markdown report (PDF compile pending).
If you want to **decide M-001 and queue the rescan** → start at `claudit/README.md`.

| # | File | Audience | Time |
|---|---|---|---|
| 1 | `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.md` | Humans, end-to-end read | ~10 min |
| 2 | `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.pdf` | Same content, print-ready (6 pages, plain visual style; see "PDF status" below) | ~10 min |
| 3 | `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.yml` | LLM agents / CI / ticket import | self-contained |
| 4 | `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.csv` | Spreadsheets / triage boards (424 rows) | — |
| 5 | `260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.scan.json` | Engine reproducibility (13.78 MB) | — |
| 6 | `claudit/README.md` | The agent-runnable remediation loop entry point | ~5 min agent run |

## Directory layout

```
260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1/
├── README.md                                                ← you are here
│
├── 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.md            ← markdown report
├── 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.pdf           ← (compile pending)
├── 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.tex           ← LaTeX source (if PDF not compiled)
├── 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.yml           ← agent-feedable YAML
├── 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.csv           ← flat triage rows (424 entries)
├── 260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.scan.json     ← raw SPECTRE JSON
│
├── claudit/                                                 ← agent-runnable epic
│   ├── README.md                                            ← entry point
│   ├── EPIC.md                                              ← architecture, waves, risks
│   └── tasks/
│       ├── 01-cargo-audit-baseline.yml                      (Wave 0)
│       ├── 02-git-state-check.yml                           (Wave 0)
│       ├── 03-m001-disposition-decision.yml                 (Wave 1; review prepared patch)
│       ├── 04-m001-apply-pin-or-ack.yml                     (Wave 1; apply)
│       ├── 05-commit-with-pinpoint-trailers.yml             (Wave 1)
│       ├── 06-rescan-with-spectre.yml                       (Wave 2)
│       ├── 07-a001-buy-core-refactor-ticket.yml             (Wave 2, follow-up)
│       └── 08-detector-improvement-feedback.yml             (Wave 2, follow-up)
│
└── regression-tests/                                        ← prepared M-001 remediation
    ├── p001_cpi030_wns_program_pin.patch                    ← unified diff (Option A idiom)
    ├── cpi030_wns_pin_test/                                 ← Rust regression-test crate
    │   ├── Cargo.toml
    │   └── src/lib.rs
    ├── scan-post-patch.json                                 ← SPECTRE JSON after patch (CPI-030 = 0)
    └── verification.log                                     ← full apply -> check -> rescan -> test transcript
```

## TL;DR — running the loop

```bash
# 1. Pre-flight (one time)
cargo install cargo-audit

# 2. Apply the prepared patch (recommended path):
git apply regression-tests/p001_cpi030_wns_program_pin.patch
cargo check -p marketplace-program

# 3. Confirm CPI-030 drops to 0:
pinpoint spectre scan . --local --output json --profile balanced --min-confidence 0.78 --languages rust
# Expected: CPI-030 = 0 (down from 12).

# 4. Confirm the regression test passes:
cargo test --features patched --manifest-path regression-tests/cpi030_wns_pin_test/Cargo.toml
# Expected: 1 passed.

# 5. Alternate paths (operator's choice):
# - Swap to handler-side require_keys_eq!  (see claudit/tasks/04 SWAP_TO_OPTION_B).
# - ACK the design with a SECURITY-NOTES.md (see claudit/tasks/04 ACK).
```

## What's been validated end-to-end

| Phase | Command | Result |
|---|---|---|
| Pre-state | `git rev-parse HEAD && git status --porcelain` | `8be7f2c`; clean |
| Pre-patch compile | `cargo check -p marketplace-program` | OK (47 unrelated cfg warnings) |
| Pre-patch scan | `pinpoint spectre scan . --profile balanced --min-confidence 0.78 --languages rust` | 424 findings; CPI-030 = 12 |
| Pre-patch unit test | `cargo test --manifest-path regression-tests/cpi030_wns_pin_test/Cargo.toml` | **FAIL** (spoofed `wns_program` accepted) |
| Apply patch | `git apply regression-tests/p001_cpi030_wns_program_pin.patch` | applied cleanly; 7 files changed |
| Post-patch compile | `cargo check -p marketplace-program` | OK |
| Post-patch scan | (same scan command) | **CPI-030 = 0** (full cluster suppressed) |
| Post-patch unit test | `cargo test --features patched ...` | **PASS** (ConstraintAddress fires on spoof) |
| Revert | `git checkout -- .` | working tree clean |
| `cargo audit --json` baseline | (separately) | 2 hard CVEs + 13 warning-class advisories; all hard CVEs transitive via solana-program 1.16.25 |

Full transcript with timestamps in `regression-tests/verification.log`.

## PDF status

The matariki-V1 reference shipped a built PDF compiled with doc-digital.sty
(LuaLaTeX or XeLaTeX with Plus Jakarta Sans / JetBrains Mono / Source Serif 4).
This V1 ships a **standalone .tex** compiled with `pdflatex` against Latin
Modern fonts. The output is the 6-page, ~228 KB PDF sitting alongside the
markdown. The visual style is plain (no glass-morphism / circuit decorations
from doc-digital) because the audit machine running this generation pass did
not have `xelatex` or the Plus Jakarta Sans / JetBrains Mono / Source Serif 4
fonts installed, and the doc-digital fontspec stack was not satisfiable inside
the timebox. To rebuild against doc-digital, swap the preamble in
`260511-SPECTRE-AUDIT-TENSOR-MARKETPLACE-V1.tex` for the doc-digital one
and compile with `lualatex` on a machine that has the font stack present.

## SPOQ methodology

The remediation epic in `claudit/` follows the SPOQ (Specialist Orchestrated
Queuing) format. Read more at [spoqpaper.com](https://spoqpaper.com).

## Naming convention

Pinpoint deliverables follow `YYMMDD-SPECTRE-AUDIT-CUSTOMER-PROJECT-Vn`.
This is V1. If Tensor confirms a disposition and a remediation commit lands,
V2 ships against the new commit.

---

## Questions

This deliverable is archived against scan commit `8be7f2c` for the public
corpus record. To coordinate on disposition or open a paid follow-up audit,
the Tensor team's published disclosure channel is `security@tensor.so` (per
their `SECURITY.md`).
