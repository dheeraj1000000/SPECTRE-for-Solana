# 260511-SPECTRE-AUDIT-JITO-RESTAKING-V1

**Customer:** Jito Foundation (public-corpus pass; no paying engagement) &nbsp;·&nbsp; **Project:** `restaking`
**Scan commit:** `e0f02a888cd3dd871e2e101f56758d33f96cdb01` &nbsp;·&nbsp; **Engine:** Pinpoint SPECTRE v1.2.0 (internal build)
**Date:** 2026-05-11 &nbsp;·&nbsp; **Version:** V1 (first SPECTRE pass; OtterSec October 2024 cross-referenced)

---

## What this is

This directory is a complete SPECTRE audit deliverable for the Jito Foundation `restaking` protocol. The pack is shipped as a public-good audit; there is no paying customer. Everything you need to read the audit, decide the disposition, schedule the recommended hardening study, and re-verify is in here.

**Outcome:**

- **0 new exploitable defects.** The published audit-of-record (OtterSec, October 2024 @ `f04242f`) closed all 8 of its findings; SPECTRE V1 surfaces a different rule family and adds zero new exploitable items beyond it.
- **1 design-level Advisory** (C-001, AUTH-100 cluster, 6 sites) — single-step authority transfer pattern. ACK with hardening recommendation: convert the four config-level admin handlers to a propose/accept handshake. Not exploitable as a third-party action; the protocol admin is multisig-operated and `vault_program::SetAdmin` already requires the new admin to co-sign.
- **No patchable items this round.** Unlike a customer engagement, this V1 pass ships no `regression-tests/` patch. Wave 1 of `claudit/` is a documented no-op which captures the disposition; Wave 2 opens the propose/accept feasibility ticket and a cargo-audit policy ticket.
- **Audit-of-record cross-check.** OtterSec 8/8 RESOLVED. The Offside and Certora vault audits in `security_audits/` are noted but not re-cross-referenced exhaustively in V1.
- **Bidirectional finding.** `cargo audit` surfaces 15 real transitive CVEs that SPECTRE missed (bytes, dalek x2, quinn-proto, rustls-webpki x7, tar x2, time, tracing-subscriber). SPECTRE's 17 DEPVULN-001 hits are all detector false positives (Cargo.toml semver matched, Cargo.lock already past the patched window). Supplemental list in §4c of the markdown.

## Reading order

If you want to **understand what we found** then start with the markdown.
If you want to **run the documented no-op disposition now** then start at `claudit/README.md`.

| # | File | Audience | Time |
|---|---|---|---|
| 1 | `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.pdf` | Humans, end-to-end read | (pending compile; see "Pending PDF" below) |
| 2 | `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.md` | Same content as the planned PDF, paste-ready for Slack/email/issue | ~10 min |
| 3 | `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.yml` | LLM agents / CI / ticket import | self-contained |
| 4 | `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.csv` | Spreadsheets / triage boards (873 rows) | — |
| 5 | `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.scan.json` | Raw scan archive (~28 MB) | — |
| 6 | `claudit/README.md` | Agent-runnable disposition loop entry point | ~5 min agent run |

## Directory layout

```
260511-SPECTRE-AUDIT-JITO-RESTAKING-V1/
├── README.md                                              ← you are here
│
├── 260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.md             ← markdown report
├── 260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.yml            ← agent-feedable YAML
├── 260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.csv            ← flat triage table (873 rows)
├── 260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.scan.json      ← raw SPECTRE scan (~28 MB)
│
└── claudit/                                              ← agent-runnable epic
    ├── README.md                                         ← entry point
    ├── EPIC.md                                           ← architecture, waves, risks
    └── tasks/
        ├── 01-cargo-audit-baseline.yml                   (Wave 0)
        ├── 02-git-state-check.yml                        (Wave 0)
        ├── 03-noop-no-patch-this-round.yml               (Wave 1)
        ├── 04-record-auth100-ack.yml                     (Wave 1)
        ├── 05-commit-with-pinpoint-trailers.yml          (Wave 1)
        ├── 06-rescan-with-spectre.yml                    (Wave 2)
        ├── 07-propose-accept-handshake-feasibility.yml   (Wave 2, follow-up)
        └── 08-cargo-audit-policy.yml                     (Wave 2, follow-up)
```

## TL;DR — running the disposition

```bash
# 1. Pre-flight (one time, on the audit machine)
cargo install cargo-audit

# 2. Hand the audit project to your agent:
#    "Read claudit/README.md and claudit/EPIC.md. Then execute every task in
#     claudit/tasks/ in dependency order, halting on first failure. There is
#     NO patch to apply this round."

# 3. After the agent finishes Wave 1, re-scan (Wave 2 task 06):
pinpoint spectre scan . --local --profile balanced --min-confidence 0.78 \
  --languages rust --output json
# Expected: identical counts (no source changed). The drop happens in V3
# after the propose/accept handshake (task 07) lands.
```

## What's been validated end-to-end

Pinpoint executed the audit loop on the audit machine before shipping. The YAML's `verification:` block has the full transcript. Highlights:

| Phase | Command | Result |
|---|---|---|
| Git state | `git rev-parse HEAD` | `e0f02a8...` |
| SPECTRE scan | `pinpoint spectre scan . --local --output json --profile balanced --min-confidence 0.78 --languages rust` | 873 findings; QUAL-003=850, DEPVULN-001=17, AUTH-100=6 |
| AUTH-100 source read | (manual) read each of the 6 handlers | 5/6 single-step (no new-admin co-sign); 1/6 (`vault_program::SetAdmin`) already two-signature |
| `cargo audit` | one-shot run against lockfile | 15 real CVEs + 14 informational warnings |
| OtterSec extract | `pdftotext security_audits/ottersec_jito_restaking_audit.pdf -` | 8 findings, all marked RESOLVED in the PDF (PR #137, #140, #141) |

Your agent's run is the second pass over a known-good path, not exploratory work.

## SPOQ methodology

The disposition epic in `claudit/` follows the SPOQ (Specialist Orchestrated Queuing) format and was validated against the standard 10-metric rubric. PASS threshold is 95 average with a 90 floor on every metric.

Read more at [spoqpaper.com](https://spoqpaper.com).

## Naming convention

Pinpoint deliverables follow `YYMMDD-SPECTRE-AUDIT-CUSTOMER-PROJECT-Vn`. This is V1 (first SPECTRE pass on `e0f02a8`). When the propose/accept handshake (or any in-scope source change) lands we will re-scan and ship V2.

## Pending PDF

The `.pdf` companion to the markdown is **not yet compiled** in this pack. The markdown is the canonical narrative; PDF compile via the project `doc-digital` LaTeX style is queued but was out of scope for the V1 timebox. If you need the typeset PDF for archival, run the project's LaTeX build against the markdown source.

## Questions

Reply via the channel this audit was delivered through, or open an issue on the Jito Foundation `restaking` repository referencing `PINPOINT-JITO-RESTAKING-C-001`.
