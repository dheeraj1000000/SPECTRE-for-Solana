# SPECTRE AUDIT — Jito Foundation / restaking (public-corpus pass)

**Filename:** `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1`

| | |
|---|---|
| **Customer** | Jito Foundation (public-good audit; no paying engagement) |
| **Project** | `restaking` — Solana native restaking + vault platform |
| **Scan commit** | `e0f02a888cd3dd871e2e101f56758d33f96cdb01` (`e0f02a8`) |
| **Engine** | Pinpoint SPECTRE v1.2.0 (internal build) |
| **Profile run** | balanced (raw count: 873; severity mix: 11 Critical / 6 High / 399 Medium / 457 Low) |
| **Date** | 2026-05-11 |
| **Report version** | V1 (first SPECTRE pass; cross-referenced against the public audit-of-record) |
| **Critical findings** | **0 new exploitable defects.** 6 architectural High-severity AUTH-100 hits (single-step admin transfer) cluster into one design-level Critical (C-001) which is partially mitigated in-tree and historically discussed in published audits. |
| **Other findings** | 11 Critical and 6 Medium DEPVULN-001 hits are detector false positives caused by a stale advisory window on `solana-program`. 850 QUAL-003 hits are dominated by generated Shank/Kinobi client code and resolve to detector-tuning signals. |
| **Validation** | Source-level read of every AUTH-100 site; `cargo audit` run end-to-end against the lockfile; published audit-of-record (OtterSec October 2024, commit `f04242f`) cross-referenced. |
| **Audit-of-record cross-check** | OtterSec 8 findings: **8 RESOLVED**, 0 outstanding (per OtterSec PDF in `security_audits/`). Offside and Certora vault audits also present in-tree; not re-cross-referenced in V1. |

---

## Executive summary

**What we did.** We re-ran SPECTRE in `balanced` profile, min-confidence 0.78, against the head of `main` for `jito-foundation/restaking` (`e0f02a8`). The raw scan returned 873 findings across three rules: `QUAL-003` ×850, `DEPVULN-001` ×17, and `AUTH-100` ×6. We then ran SPECTRE's disproval pass: every AUTH-100 site was read against the source to confirm the rule's signal, every DEPVULN-001 entry was reconciled against the actual `Cargo.lock` resolved version, and QUAL-003 hits were sampled across files and binned by code-origin (hand-written vs generated).

**Headline result.** SPECTRE surfaces **zero new exploitable defects** beyond what the published audit-of-record (OtterSec, October 2024) already closed. The 6 AUTH-100 sites are all true positives at the rule level (the program does expose single-step authority changes), but the operational risk is bounded by the fact that the protocol is administered by a multisig and that `set_admin` on a vault already requires the new admin to co-sign the transfer (`vault_program/src/set_admin.rs:19`). We bucket the cluster as one design-level finding C-001 (Advisory severity in our judgment, even though the rule classifies it as High) and recommend a propose/accept handshake on the four config-level admin handlers as a hardening improvement, not as an exploitable defect that requires an emergency patch.

**No patchable items this round.** Unlike the matariki V1 audit, this V1 pass ships no `regression-tests/` patch. The AUTH-100 cluster is a design-level recommendation that warrants a feasibility study (Wave 2 ticket) rather than a same-sprint cleanup. The DEPVULN-001 false positives and the QUAL-003 noise are Pinpoint-side detector improvements, not in-tree changes. Wave 1 of the `claudit/` epic is therefore a **documented no-op** which captures the disposition for each finding bucket and reaffirms the OtterSec ACKs without modifying tree state.

**Audit-of-record cross-check.** The repository ships four published audit PDFs in `security_audits/`: OtterSec (October 2024, commit `f04242f`, 8 findings), Offside (vault audit), and Certora (v1 and v2 vault audits). We extracted the OtterSec findings table and confirmed all 8 are marked RESOLVED in the audit itself (OS-JRS-ADV-00 through 04 plus OS-JRS-SUG-00 through 02), with linked Jito PR numbers. None of those resolved findings re-appear in the SPECTRE V1 set; the SPECTRE detectors run on a different rule family and surface a distinct (admin-transfer + advisory-CVE-window + fan-out-metric) signal. The Offside and Certora cross-references are noted but not re-checked exhaustively in V1; the OtterSec PDF is the audit-of-record cited in this report.

**Bidirectional finding.** We ran `cargo audit` end-to-end against the lockfile (DB last-updated 2026-05-11, 1069 advisories, 752 deps). `cargo audit` reports **15 vulnerabilities plus 14 informational warnings**. SPECTRE's `DEPVULN-001` detector matched 17 `Cargo.toml` semver strings, all of which are false positives (the lockfile resolves `solana-program` to 2.2.1, well past the unmaintained 1.x window that triggered CVE-2022-35949; `chrono` and `tokio` are similarly past their respective advisory windows). The 15 real CVEs `cargo audit` surfaces are mostly transitive via `solana-program 2.2.7`'s `quinn`/`rustls-webpki`/`bytes` deps and via `tar`/`time` in tooling crates. Full list in §4c.

The remaining 850 QUAL-003 hits are detector-tuning signals. Of the top-10 file hot-spots, 9 are auto-generated Shank/Kinobi client code under `clients/rust/{restaking_client,vault_client}/src/generated/instructions/`. These are codegen artifacts, not hand-written code; high fan-out is a property of every `instructions/<ix>.rs` file the codegen emits. The remaining hand-written hot-spot is `vault_core/src/vault.rs` (12 sites at fan-out 16–17, just barely over the threshold). All map to detector improvements on Pinpoint's side, not code change in `restaking`.

### How this report is laid out

1. **Executive summary** — method, headline, layout (this section).
2. **Findings snapshot** — one-table view of C-001 (AUTH-100 cluster), the LC buckets, and the audit-of-record cross-reference.
3. **Detailed Finding Records** — `C-001` (single-step authority transfer, six sites).
4. **Other Findings appendix** — advisories (`A-001`), lower-confidence groups (`LC-001/002`).
4b. **Audit-of-record cross-check** — OtterSec findings re-mapped against the V1 scan.
4c. **`cargo audit` supplement** — real transitive CVEs SPECTRE missed; bidirectional detector-gap entry.
5. **Workflow integration & delivery channels** — how this report fits into the audit loop.
6. **Claudit** — agent-runnable companion epic at `claudit/` (Wave 1 is a documented no-op; Wave 2 is feasibility + cargo-audit policy).

### Three views, one source of truth

You receive this audit as four artifacts plus the raw scan, all derived from the same scan run against the same commit:

| Artifact | Audience | Purpose |
|---|---|---|
| `…JITO-RESTAKING-V1.pdf` | Humans | Executive narrative; what to read end-to-end. (Pending compile; see §README "pending PDF".) |
| `…JITO-RESTAKING-V1.md` | Slack / email / PR descriptions | This file. Same content as the planned PDF in plain Markdown. |
| `…JITO-RESTAKING-V1.yml` | Agents / CI / ticket import | One YAML record per finding bucket with rule ID, scan commit, severity, confidence, and ticket-lifecycle metadata. |
| `…JITO-RESTAKING-V1.csv` | Spreadsheets / triage boards | Flat row-per-finding view (873 rows); sortable, filterable, joinable to existing trackers. |
| `…JITO-RESTAKING-V1.scan.json` | Raw scan archive | The exact JSON emitted by `pinpoint spectre scan`; ground truth for everything else. |

The `claudit/` directory holds the agent-runnable epic.

---

## 1. Findings — snapshot

| ID | Sev | Conf. | Where | Disposition |
|---|---|---|---|---|
| `C-001` | Advisory (rule says High) | Med | 6 admin-transfer instructions across `vault_program/src/lib.rs` and `restaking_program/src/lib.rs` | **ACK with hardening recommended.** Multisig-administered today; a propose/accept handshake on the four config-level handlers is a reasonable next-sprint study. Not exploitable as an unsigned third-party action. |

### Other findings — snapshot

| ID | Class | Sev | Conf. | Title |
|---|---|---|---|---|
| `A-001` | advisory | Low | Med | High-fan-out helpers in hand-written `vault_core/src/vault.rs` (12 sites, all 16-17 fan-out, barely over the QUAL-003 threshold of 15) |
| `LC-001` | lower-conf. | Critical\* | Unlikely | DEPVULN-001 — `Cargo.toml` semver matched a vulnerable window, lockfile already resolves past it (17 sites; covers `solana-program`, `chrono`, `tokio`) |
| `LC-002` | lower-conf. | Low\* | Unlikely | QUAL-003 — Shank/Kinobi codegen artifacts under `clients/rust/*/src/generated/instructions/` (~838 sites) |

\* Severity is the rule's raw classification; confidence is our verified read. "Lower-confidence" findings should drive detector tuning, not code change in `restaking`.

---

## 2. Detailed Finding Records

### `PINPOINT-JITO-RESTAKING-C-001` — single-step authority transfer cluster

| | |
|---|---|
| **Rule** | AUTH-100 |
| **Severity (rule)** | High |
| **Severity (audit judgment)** | Advisory |
| **Confidence** | Medium |
| **Profile** | balanced |
| **Audit-of-record mapping** | Not in OtterSec scope (OtterSec focused on `process_burn_withdrawal_ticket` and slashing semantics). |
| **Disposition** | ACK with hardening recommended; schedule propose/accept handshake feasibility study for the four config-level handlers. |

**Affected locations.** Six instruction-dispatch arms; each routes to a handler that mutates an authority field in one go. All six were read against source.

| Program | Dispatch site | Handler source | Old admin co-signs? | New admin co-signs? |
|---|---|---|---:|---:|
| `vault_program` | `lib.rs:153` `SetSecondaryAdmin(role)` | `set_secondary_admin.rs:11-72` | Yes (`load_signer(admin, false)?`) | **No** |
| `vault_program` | `lib.rs:157` `SetAdmin` | `set_admin.rs:10-26` | Yes | **Yes** (`load_signer(new_admin, false)?` at `:19`) |
| `vault_program` | `lib.rs:213` `ChangeWithdrawalTicketOwner` | `change_withdrawal_ticket_owner.rs:11-41` | Yes (old staker) | **No** |
| `vault_program` | `lib.rs:287` `SetConfigAdmin` | `set_config_admin.rs:11-26` | Yes | **No** |
| `vault_program` | `lib.rs:291` `SetConfigSecondaryAdmin(role)` | `set_config_secondary_admin.rs:16-40` | Yes | **No** |
| `restaking_program` | `lib.rs:192` `SetConfigAdmin` | `set_config_admin.rs:11-26` | Yes | **No** |

**Description.** Five of the six handlers commit the new authority key to state under the old admin's signature alone, without the new authority needing to demonstrate control of the destination key. `vault_program::SetAdmin` is the exception and already requires both keys to sign the same transaction (`set_admin.rs:19`); this is a partial mitigation that makes a typo-driven loss-of-control scenario much less likely for the primary vault admin role.

**Impact.** Rule-level: loss of admin control via a fat-fingered or compromised single-step transfer is unrecoverable, because the prior admin can no longer sign anything against the program after the transfer lands. Audit-judgment level: in practice the Jito protocol admin is a multisig (per protocol documentation), which means the "compromised single key" scenario already requires multisig key compromise rather than a single key compromise. The remaining surface is the operator-error scenario, since a multisig that approves a wrongly-typed pubkey can still fat-finger the destination and lock out the protocol admin role. `ChangeWithdrawalTicketOwner` is per-staker and per-ticket; its blast radius is one withdrawal ticket, not the protocol. We do not classify it with the other five for severity purposes.

The historical-incident bundle the rule attaches (Wormhole, Drift v2, Step Finance) is mostly off-pattern here; those incidents involved signature verification bypass or multisig social engineering rather than a literal single-step `set_admin`. The rule is firing on a structural shape, not on a matched-incident root cause.

**Why we do not call this Critical.**

1. The protocol admin is operated as a multisig (per public protocol documentation and the `security_audits/` folder's audit scope notes).
2. `vault_program::SetAdmin` already implements the two-signature variant (old + new co-sign), so the most-asset-bearing role has the desired property.
3. No published audit (OtterSec October 2024) flagged this pattern as a finding in scope. OtterSec's scope was the burn-withdrawal-ticket flow and slashing math.
4. The exploit path requires the operator (multisig) to approve a transfer to a pubkey they do not control; there is no third-party path to invoke these handlers.

**Recommended hardening (feasibility study, NOT a same-sprint patch).** Convert the four `Set*ConfigAdmin` and `Set*SecondaryAdmin` handlers into the first step of a two-phase transfer:

1. Add `pending_admin: Pubkey` (and per-role pending fields for secondary admins) to the `Config` PDA.
2. `SetConfigAdmin` stages the requested new admin into `pending_admin`; the current admin signs as today.
3. A new `AcceptConfigAdmin` instruction must run under the new admin's signature and commits `pending_admin` into `admin`.
4. Optionally also add a timelock between propose and accept to give the multisig a window to abort a wrong-pubkey staging.

`vault_program::SetAdmin` already has the new-admin co-signature; the migration cost there is purely cosmetic (rename to `Propose`/`Accept` for consistency). `ChangeWithdrawalTicketOwner` could plausibly stay single-step since its blast radius is per-ticket, but mirroring the staged-transfer pattern would harmonize the program surface.

**Wave 1 action.** None. Document the disposition in `SECURITY-NOTES.md` (or equivalent) referencing this V1 audit; open a Wave 2 feasibility-study ticket via `claudit/tasks/07-propose-accept-handshake-feasibility.yml`.

---

## 4. Other Findings — appendix

### `A-001` — high-fan-out helpers in `vault_core/src/vault.rs` (advisory; 12 sites)

Twelve helper functions in `vault_core/src/vault.rs` trip the QUAL-003 fan-out threshold of 15, all at fan-out 16-17. Sample sites:

| Helper | Line | Fan-out |
|---|---:|---:|
| `burn_with_fee` | 1060 | 16 |
| `calculate_additional_supported_assets_needed_to_unstake` | 1135 | 17 |
| `calculate_supported_assets_requested_for_withdrawal` | 1117 | 17 |

These are pure math/accounting helpers; the fan-out is dominated by `checked_*` arithmetic and `Result` propagation rather than business logic complexity. Audit-readiness concern at most. Recommend leaving as-is and bumping the QUAL-003 threshold on Pinpoint's side for hand-written numeric helpers (see `LC-002`).

### Lower-confidence findings (detector tuning, not code change)

| ID | Rule | Sites | Why lower-confidence | Detector improvement |
|---|---|---:|---|---|
| `LC-001` | DEPVULN-001 | 17 | All hits are `Cargo.toml` semver matches against advisory windows that the actual lockfile resolution exceeds. `solana-program` resolves to `2.2.1` in `Cargo.lock`; CVE-2022-35949 applies to the unmaintained 1.x. `chrono` resolves to a post-`0.4.20` version that fixes RUSTSEC-2020-0071 / CVE-2020-26235. `tokio` resolves past the `1.18.5` / `1.20.4` / `1.23.1` patch windows for CVE-2023-22466. | Walk `Cargo.lock`, not `Cargo.toml`. Compare each `[[package]]` against the advisory window. Same change closes the 15 real CVEs that `cargo audit` finds (see §4c). |
| `LC-002` | QUAL-003 | ~838 of 850 | Of the top-10 file hot-spots, 9 are auto-generated Shank/Kinobi client code under `clients/rust/{restaking,vault}_client/src/generated/instructions/`. Codegen emits identical 12-fan-out boilerplate per instruction. The 12 hand-written hot-spots in `vault_core/src/vault.rs` (16-17 fan-out) are bucketed as `A-001` instead. | Suppress QUAL-003 on files under `*/src/generated/` (or detect the Shank/Kinobi codegen marker comment at top of file). Optionally raise the fan-out threshold for pure-arithmetic helpers. |

---

## 4b. Audit-of-record cross-check

The repository ships four published audit PDFs in `security_audits/`. **OtterSec October 2024** (commit `f04242f`, 8 findings, all RESOLVED per the PDF) is the audit-of-record for `restaking_program`. **Offside** and **Certora v1/v2** focus on the vault and were not re-cross-referenced exhaustively in V1; their fix status is presumed inherited unless a re-scan of the relevant commits says otherwise.

| OtterSec ID | Sev | Title | Status (per OtterSec PDF) | SPECTRE V1 re-check |
|---|---|---|---|---|
| OS-JRS-ADV-00 | Critical | Unauthorized Withdrawal of Unstaked Amount via burn instruction | RESOLVED (PR #137) | **Not surfaced.** SPECTRE V1 does not have an equivalent detector. Resolution inherited. |
| OS-JRS-ADV-01 | High | Slashing-Induced Share Dilution | RESOLVED (PR #141) | **Not surfaced.** Slashing instruction was removed per the fix; SPECTRE has no detector for share-dilution math. |
| OS-JRS-ADV-02 | High | DOS Due to Withdrawal Ticket Desynchronization | RESOLVED (PR #140) | **Not surfaced.** Token-account balance is now read on-chain per the fix. |
| OS-JRS-ADV-03 | High | Lack of Permission Checks on `process_burn_withdrawal_ticket` | RESOLVED | **Not surfaced.** |
| OS-JRS-ADV-04 | High | Vault Share Inflation Risk on first deposit | RESOLVED | **Not surfaced.** |
| OS-JRS-SUG-00 | Info | Unsafe SPL Token ID Handling | RESOLVED | n/a |
| OS-JRS-SUG-01 | Info | Risk of Over-withdrawing | RESOLVED | n/a |
| OS-JRS-SUG-02 | Info | Code Maturity | RESOLVED | n/a |

**Take-away.** SPECTRE V1's detector family is mostly orthogonal to OtterSec's findings: OtterSec focused on bet-economic (burn, slashing, share inflation) and access-control-on-permissionless-handler patterns; SPECTRE V1 focuses on admin-key rotation shape (AUTH-100), dependency advisories (DEPVULN-001), and code-complexity metrics (QUAL-003). The lack of overlap is informative for both directions: SPECTRE V1 does not reproduce OtterSec's depth on bet-economic correctness, and OtterSec did not flag the admin-rotation pattern that SPECTRE highlights (which is consistent with our judgment that the multisig-operated admin makes the rotation pattern a hardening item rather than an exploit).

---

## 4c. `cargo audit` supplement

We ran `cargo audit` against the lockfile end-to-end on the audit machine. Database last-updated 2026-05-11; 1069 advisories; 752 deps. The tool reports **15 vulnerabilities and 14 informational warnings**. All 15 are transitive via the `solana-program 2.2.7` and tooling-crate (tar, time, tracing-subscriber) dep chains; the `restaking` crates do not depend on any of them directly.

| Advisory | Package | Lockfile version | Patched in | Title |
|---|---|---|---|---|
| RUSTSEC-2026-0007 | bytes | 1.10.0 | `>=1.11.1` | Integer overflow in `BytesMut::reserve` |
| RUSTSEC-2024-0344 | curve25519-dalek | 3.2.0 | `>=4.1.3` | Timing variability in `Scalar29::sub`/`Scalar52::sub` |
| RUSTSEC-2022-0093 | ed25519-dalek | 1.0.1 | `>=2` | Double Public Key Signing Function Oracle Attack |
| RUSTSEC-2026-0037 | quinn-proto | 0.11.9 | `>=0.11.14` | DoS in Quinn endpoints |
| RUSTSEC-2026-0104 | rustls-webpki | 0.101.7 | `>=0.103.13` | Reachable panic in CRL parsing |
| RUSTSEC-2026-0099 | rustls-webpki | 0.101.7 | `>=0.103.12` | Name constraints accepted for wildcard certificates |
| RUSTSEC-2026-0098 | rustls-webpki | 0.101.7 | `>=0.103.12` | Name constraints for URI names incorrectly accepted |
| RUSTSEC-2026-0104 | rustls-webpki | 0.102.8 | `>=0.103.13` | Reachable panic in CRL parsing (second resolution) |
| RUSTSEC-2026-0099 | rustls-webpki | 0.102.8 | `>=0.103.12` | Name constraints for wildcards (second resolution) |
| RUSTSEC-2026-0098 | rustls-webpki | 0.102.8 | `>=0.103.12` | Name constraints for URI names (second resolution) |
| RUSTSEC-2026-0049 | rustls-webpki | 0.102.8 | `>=0.103.10` | CRLs not authoritative by Distribution Point |
| RUSTSEC-2026-0068 | tar | 0.4.43 | `>=0.4.45` | PAX size headers ignored if header size nonzero |
| RUSTSEC-2026-0067 | tar | 0.4.43 | `>=0.4.45` | `unpack_in` can chmod arbitrary directories via symlinks |
| RUSTSEC-2026-0009 | time | 0.3.37 | `>=0.3.47` | DoS via stack exhaustion |
| RUSTSEC-2025-0055 | tracing-subscriber | 0.3.19 | `>=0.3.20` | ANSI escape sequences in logged user input |

Plus 14 informational warnings (unmaintained: `atty`, `bincode`, `derivative`, `libsecp256k1`, `paste`, `proc-macro-error`, `yaml-rust`; yanked: `keccak`; etc.). None of the 15 hit on-chain attack surface directly; quinn/rustls/bytes/tar/time/tracing-subscriber are off-chain tooling and SDK code paths.

**Recommended action.**

1. Track `solana-program-sdk` upgrade cadence. Most of the rustls/quinn/dalek pins resolve when Jito bumps `solana-program` past 2.2.7.
2. Bump `tar` to `>=0.4.45` and `time` to `>=0.3.47` independently in tooling crates if possible (these are direct-dep updates and do not require waiting on solana-sdk).
3. If you wish to silence noise during normal development, ship a `deny.toml` with `RUSTSEC-*` ignore entries that document the "transitive via solana-program-sdk" rationale; template under `claudit/tasks/04-cargo-audit-policy.yml`.

**Detector improvement on Pinpoint side (logged internally).** `DEPVULN-001` should walk `Cargo.lock` rather than matching `Cargo.toml` semver. Same change closes both directions: the 17 false positives in `LC-001` and these 15 missed real CVEs.

---

## 5. Workflow integration & delivery channels

### The audit loop

1. **Audit.** The four artifacts in this directory (`.md` / `.yml` / `.csv` / `.scan.json`) plus the planned `.pdf` (pending compile).
2. **Feed.** Drop the `.yml` into your LLM (or Pinpoint MCP server); each finding bucket is self-contained.
3. **Disposition.** Since Wave 1 has no patch, the work this round is documentation:
   - Open a propose/accept-handshake feasibility ticket (Wave 2 task 07).
   - Open a cargo-audit policy ticket (Wave 2 task 04).
   - Decide whether to acknowledge the AUTH-100 cluster in a `SECURITY-NOTES.md`-style file inside the repository (recommended for the audit chain).
4. **Re-audit.** When the propose/accept handshake lands, re-run `pinpoint spectre scan` against that commit and ship V2.

### Naming & versioning

Every Pinpoint deliverable follows `YYMMDD-SPECTRE-AUDIT-CUSTOMER-PROJECT-Vn`. This is V1 (first SPECTRE pass on `e0f02a8`). The next version would be V2 after the recommended handshake handlers land or after a fresh scan against a newer head commit, whichever comes first.

### Suggested order of work

1. **Wave 2 ticket — feasibility study (the C-001 handshake).** Two-phase transfer for the four config-level admin handlers in `vault_program` and `restaking_program`. ~1 sprint of work plus LiteSVM proof.
2. **Wave 2 ticket — cargo-audit policy.** Pin the transitive deps that have direct-update paths (`tar`, `time`); document the solana-sdk-transitive ones; ship a `deny.toml` or equivalent.
3. **Pinpoint-side, parallel.** Detector improvements for LC-001 (walk Cargo.lock) and LC-002 (suppress on `*/src/generated/`) land in the next engine release; on V2 of this audit they will not surface.

---

## 6. Claudit — the agent-runnable remediation epic

The disposition in §5 is packaged as a SPOQ-flavoured task graph so an LLM agent can run the *audit → disposition → ticket → reaffirm → rescan* loop end-to-end without copy-paste.

### What's in the box

- `claudit/README.md` — entry point. Hand the audit project to your agent and point it here.
- `claudit/EPIC.md` — architecture, wave breakdown, dependency table, risk register.
- `claudit/tasks/01-08` — eight atomic task YAMLs. Wave 0 captures pre-flight state; Wave 1 is a documented no-op (no patch to apply) plus a `SECURITY-NOTES.md`-style ACK note; Wave 2 is the propose/accept handshake feasibility ticket and the cargo-audit policy ticket.

### Wave structure

| Wave | Tasks | Purpose |
|---|---|---|
| Wave 0 | 01 cargo-audit-baseline · 02 git-state-check | Pre-flight: capture baseline, assert HEAD is `e0f02a8`. |
| Wave 1 | 03 noop-no-patch-this-round · 04 record-auth100-ack · 05 commit-with-pinpoint-trailers | Document the ACK without modifying program source. |
| Wave 2 | 06 rescan-with-spectre · 07 propose-accept-handshake-feasibility · 08 cargo-audit-policy | Follow-up tickets and re-audit. |

### Validated against the 10-metric SPOQ rubric

The epic was scored against the standard SPOQ epic-validation rubric before shipping; PASS threshold is 95 average with a 90 floor on every metric. Read more about the SPOQ methodology and rubric at [spoqpaper.com](https://spoqpaper.com).

---

Reply with any questions, or once the propose/accept handshake (or any other in-scope change) lands we will re-scan against the new head and ship V2.
