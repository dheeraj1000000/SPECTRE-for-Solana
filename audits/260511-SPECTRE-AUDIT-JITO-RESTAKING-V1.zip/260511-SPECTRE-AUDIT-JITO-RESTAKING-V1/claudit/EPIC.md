# Epic: claudit-jito-restaking-v1

**Audit:** `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1`
**Repo:** `jito-foundation/restaking` @ commit `e0f02a888cd3dd871e2e101f56758d33f96cdb01`
**Owner:** Jito Foundation (public-corpus audit; no paying engagement)
**Engagement type:** SPECTRE first-pass + claudit-driven disposition loop (no patch this round)

---

## Vision and overview

The 2026-05-11 SPECTRE scan against `jito-foundation/restaking` surfaced 873 raw findings under the `balanced` profile at min-confidence 0.78. The disproval pass narrowed these to:

- **0 new exploitable defects** beyond what OtterSec (October 2024, audit-of-record at commit `f04242f`) already closed. All 8 OtterSec findings are marked RESOLVED in the published PDF.
- **1 design-level Advisory** (C-001, AUTH-100 cluster, 6 sites in `vault_program` and `restaking_program`). The pattern is "single-step authority transfer," judged Advisory rather than the rule's raw "High" because the protocol admin is multisig-operated and `vault_program::SetAdmin` already requires the new admin to co-sign.
- **1 handler advisory** (A-001, 12 high-fan-out helpers in `vault_core/src/vault.rs`, all just over the QUAL-003 threshold). Audit-readiness at most.
- **Two lower-confidence buckets** (LC-001 17 DEPVULN-001 false positives; LC-002 ~838 QUAL-003 hits on Shank/Kinobi codegen). Detector-side improvements on Pinpoint, not in-tree changes.

Plus a **bidirectional finding**: SPECTRE missed 15 real transitive CVEs that `cargo audit` catches via the `solana-program 2.2.7` and tooling dep chains.

The scope of this epic's automated change is intentionally narrow. **Wave 1 applies no patch.** The AUTH-100 cluster is a design-level recommendation; the right next step is a feasibility study, not a same-sprint cleanup. Wave 1 instead records the ACK in a `SECURITY-NOTES.md`-style note so the audit chain is traceable from a commit, then stops. Wave 2 opens two follow-up tickets and re-runs SPECTRE to confirm counts are unchanged (since no source landed).

The work is self-contained. Validation is via the YAML's `verification:` block plus the Wave 2 rescan (counts should match V1 since the only change is a docs file).

Pinpoint rehearsed every step on the audit machine before shipping; see the `verification:` block in the YAML for the recorded log. The agent's run should be the second pass over a known-good path, not exploratory work.

---

## Architecture

```
+--------------------------------------------------------------------------------+
|              CLAUDIT DISPOSITION LOOP - jito-restaking V1                      |
+--------------------------------------------------------------------------------+
|                                                                                |
|   +---------------------+      +---------------------------+                   |
|   |  Audit deliverable  |      |  Customer repo             |                  |
|   |  (this directory)   |      |  restaking @ e0f02a8       |                  |
|   |  - findings YAML    |----->|  SECURITY-NOTES.md (new)   |                  |
|   |  - no patch         |      |  (no source files touched) |                  |
|   |  - ACK note text    |      |                            |                  |
|   +----------+----------+      +-----------+----------------+                  |
|              |                             |                                   |
|              v                             v                                   |
|   +--------------------------------------------------------+                   |
|   |  Wave 0: Pre-flight                                    |                   |
|   |  01 cargo-audit-baseline (capture 15 transitive CVEs)  |                   |
|   |  02 git-state-check (assert HEAD == e0f02a8)           |                   |
|   +-------------------------+------------------------------+                   |
|                             |                                                  |
|                             v                                                  |
|   +--------------------------------------------------------+                   |
|   |  Wave 1: NO-PATCH + ACK note + commit (single PR)      |                   |
|   |  03 noop-no-patch-this-round (document why)            |                   |
|   |  04 record-auth100-ack (append paragraph to NOTES)     |                   |
|   |  05 commit-with-pinpoint-trailers (2 trailers)         |                   |
|   +-------------------------+------------------------------+                   |
|                             |                                                  |
|                             v                                                  |
|   +--------------------------------------------------------+                   |
|   |  Wave 2: Re-audit + follow-up tickets                  |                   |
|   |  06 rescan-with-spectre (counts unchanged expected)    |                   |
|   |  07 propose-accept-handshake-feasibility (ticket only) |                   |
|   |  08 cargo-audit-policy (ticket only)                   |                   |
|   +--------------------------------------------------------+                   |
|                                                                                |
+--------------------------------------------------------------------------------+
```

---

## Components

### 1. Pre-flight (Wave 0, tasks 01 + 02)

- **01 cargo-audit-baseline.** Runs `cargo audit` to confirm the 15-CVE supplemental list in `yaml.cargo_audit_supplement` still matches the current `Cargo.lock`. Captures output for archival.
- **02 git-state-check.** Asserts `git rev-parse HEAD == e0f02a8` and `git status --short` is clean.

### 2. Wave 1 — documented no-op (task 03)

There is **no patch this round**. The AUTH-100 cluster is a design-level recommendation; the right next step is a propose/accept handshake feasibility study, not a single-line cleanup. Task 03 simply documents this and produces no source mutation. The task exists so the wave structure remains traceable in the agent log.

### 3. AUTH-100 ACK note (Wave 1, task 04)

**Source:** `yaml.critical_findings[0].security_notes_text`.
**Effect:** Appends a one-paragraph note to `SECURITY-NOTES.md` (or a team-chosen equivalent, since the repo does not currently ship one) documenting that the V1 SPECTRE audit re-checked the admin-rotation surface and judged it Advisory with a recommended hardening path. The paragraph carries the V1 scan-commit reference so the audit chain is traceable from the audit-trail commit.

### 4. Audit-trail commit (Wave 1, task 05)

Single commit with two trailers:
- `Pinpoint-Finding-Acknowledged: PINPOINT-JITO-RESTAKING-C-001` (records the ACK)
- `Pinpoint-Scan-Commit: e0f02a8...` (links the V2 re-audit back to V1)

### 5. Re-audit (Wave 2, task 06)

**Command:** `pinpoint spectre scan . --local --output json --profile balanced --min-confidence 0.78 --languages rust`
**Expected:** Counts identical to V1 (QUAL-003=850, DEPVULN-001=17, AUTH-100=6), since no source files were modified. The drop is expected in V3 when the propose/accept handshake lands.

### 6. Follow-up tickets (Wave 2, tasks 07 + 08)

- **07 propose-accept-handshake-feasibility.** Opens a ticket scoping the two-phase admin-transfer mitigation for C-001. Includes the proposed Config-PDA field, the propose/accept instruction pair, the optional timelock, and the LiteSVM proof sketch. Does NOT implement.
- **08 cargo-audit-policy.** Opens a ticket for the two direct dep bumps (`tar` to `>=0.4.45`, `time` to `>=0.3.47`) plus a `deny.toml` template that documents the solana-program-sdk-transitive RUSTSEC ignores. Does NOT implement.

---

## Waves

### Wave 0 — Pre-flight (~2 min)

| Task | Title | Depends on |
|------|-------|------------|
| 01 | cargo-audit-baseline | (none) |
| 02 | git-state-check | (none) |

Tasks 01 and 02 are independent; they may run in parallel.

### Wave 1 — No-op + ACK note + commit (~3 min)

| Task | Title | Depends on |
|------|-------|------------|
| 03 | noop-no-patch-this-round | 02 |
| 04 | record-auth100-ack | 02 |
| 05 | commit-with-pinpoint-trailers | 03, 04 |

Tasks 03 and 04 are independent of each other (one is a docstring task; the other touches `SECURITY-NOTES.md`); they may run in parallel.

### Wave 2 — Re-audit + follow-up tickets (~3 min)

| Task | Title | Depends on |
|------|-------|------------|
| 06 | rescan-with-spectre | 05 |
| 07 | propose-accept-handshake-feasibility | (none; opens ticket only) |
| 08 | cargo-audit-policy | (none; opens ticket only) |

---

## Success Criteria

- [ ] Wave 0 pre-flight passes (HEAD at `e0f02a8`; working tree clean).
- [ ] Wave 1 commit lands on a feature branch (recommend `spectre-v1-auth100-ack`).
- [ ] Commit message carries the two Pinpoint-* trailers verbatim.
- [ ] Commit touches exactly one file (the notes file; no source under `*_program/`, `*_core/`, etc.).
- [ ] Wave 2 rescan shows AUTH-100 = 6, DEPVULN-001 = 17, QUAL-003 = 850 (unchanged from V1).
- [ ] Tasks 07 and 08 produce one tracker ticket each (Linear / Jira / GitHub Issues) for next sprint.

---

## Task Dependencies

```
Phase 0 (pre-flight, parallel):
  01 cargo-audit-baseline      (no deps)
  02 git-state-check           (no deps)

Phase 1 (no-op note + ACK; both depend on phase-0 git check):
  03 noop-no-patch-this-round  (deps: 02)
  04 record-auth100-ack        (deps: 02)

Phase 2 (commit; depends on both phase-1 steps):
  05 commit-with-pinpoint-trailers   (deps: 03, 04)

Phase 3 (re-audit; depends on the commit):
  06 rescan-with-spectre       (deps: 05)

Phase 4 (follow-up tickets; independent):
  07 propose-accept-handshake-feasibility    (no deps; opens ticket only)
  08 cargo-audit-policy                      (no deps; opens ticket only)
```

Critical path: 02 → 04 → 05 → 06 (~6 min wall-clock). Tasks 01, 03, 07, 08 parallelise off this path.

---

## Dispatch Strategy

Single-agent dispatch is the default and the rehearsed shape: one Claude session executes all 8 tasks in dependency order, halting on first failure.

Recommended tooling per phase:

| Phase | Agent role | Tools needed |
|------:|------------|--------------|
| 0     | shell + jq | `cargo audit`, `git`, `jq`            |
| 1     | git + md   | file edit (notes file only)           |
| 2     | git        | `git commit` with heredoc trailers    |
| 3     | shell + jq | `pinpoint spectre scan`, `jq`         |
| 4     | tracker API| Linear / Jira / GitHub Issues         |

Halt-on-failure policy: every task's `description` block ends with a `CRITICAL: Agent execution rules` section that names the explicit halt conditions. The agent must surface failures verbatim and stop; in particular, **do not attempt to write a propose/accept handshake implementation as part of Wave 1** — that is task 07's ticket scope, not Wave 1 work.

---

## Risks

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| Repo does not have an existing `SECURITY-NOTES.md` for the agent to append to | Low | High | Task 04 creates the file if absent and seeds it with a one-line header before the V1 paragraph. |
| Hidden pre-commit hooks reject docs-only commits | Medium | Low | Task 05 explicitly forbids `--no-verify`. If hooks fail, the agent surfaces them and lets the operator decide. |
| Re-audit (task 06) runs against the wrong commit (still on `e0f02a8`) | Low | Low | Task 06 asserts `HEAD ≠ e0f02a8` and reads the commit trailer to confirm the audit chain. |
| Ticket tooling not configured in the agent's environment | Low | Medium | Tasks 07 and 08 fall back to printing the ticket body verbatim to stdout and instruct the operator to paste into the team's tracker. |
| Operator misreads C-001 as "needs patch this sprint" rather than "ACK with hardening study" | Medium | Low | The C-001 record in the YAML, the README cover sheet, and the commit trailer all use `ACK with hardening recommended` and `Pinpoint-Finding-Acknowledged:` to make the disposition unambiguous. |
| Engine V2 detector improvements land before re-audit (changing baseline counts) | Low | Low | Task 06 sources expected counts from `yaml.summary.findings_by_rule`; if Pinpoint ships an engine update that closes detector-side gaps (LC-001/LC-002), the operator updates expected counts before running task 06. |

## Out of scope

- The 838 QUAL-003 codegen hits (LC-002). These are detector improvements on Pinpoint's side; expect them to disappear from V2 of this audit independently of any change the team makes.
- The 17 DEPVULN-001 false positives (LC-001). Same shape: Pinpoint-side fix, walk `Cargo.lock`.
- The propose/accept handshake implementation for C-001. Task 07 opens a feasibility ticket; the implementation is a separate next-sprint PR.
- The Offside and Certora cross-references. V1 cross-checked OtterSec only; the other audits are noted in the YAML for completeness.

---

## Confidence and rehearsal record

Every Wave 0 + Wave 1 task in this epic was rehearsed end-to-end on the same codebase, same commit, same toolchain on 2026-05-11:

- `cargo audit` ran and reported 15 vulnerabilities + 14 informational warnings.
- `git rev-parse HEAD == e0f02a888cd3dd871e2e101f56758d33f96cdb01` confirmed.
- SPECTRE scan ran and emitted the 873 findings archived as `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.scan.json`.
- All six AUTH-100 handler sources were read and their dispositions recorded in the YAML's `critical_findings[0].sites` block.
- OtterSec PDF extracted via `pdftotext` and 8 findings confirmed marked RESOLVED in the audit-of-record.

Full transcript and command list in `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.yml` → `verification.evidence[]`.
