# `claudit` — Claude-driven audit disposition loop (Jito Restaking V1)

This directory packages the audit findings, the AUTH-100 ACK note, and a SPOQ-style task graph so an LLM agent (or a human) can run the **audit → disposition → ACK note → commit → rescan** loop end-to-end without copy-paste.

**This V1 ships no patch.** Wave 1 is a documented no-op: the AUTH-100 cluster is a design-level recommendation, not a same-sprint cleanup. The agent records the ACK in a `SECURITY-NOTES.md`-style note (the team chooses the destination file), commits with audit-trail trailers, and stops.

You receive this as part of the SPECTRE deliverable. Hand the entire audit project directory to Claude and say:

> *"Run claudit on `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1`."*

Claude will read this README, load the YAML, and execute the tasks in `claudit/tasks/` in dependency order. By the end, your repo will have:

- A `SECURITY-NOTES.md`-equivalent note appended documenting the V1 AUTH-100 ACK (six admin-transfer sites) with the V1 scan-commit marker.
- A single commit on a feature branch with the Pinpoint audit-trail trailers.
- Two follow-up tickets in your tracker: the propose/accept handshake feasibility study (C-001 hardening) and the cargo-audit policy ticket (`tar`/`time` direct bumps plus deny.toml template).

---

## What is "claudit"?

A `claudit` is the agent-runnable companion to a static audit report. The SPECTRE PDF / MD / CSV are for humans; the YAML is for LLMs; this directory is the **execution plan**.

```
claudit/
├── README.md                                       ← you are here
├── EPIC.md                                         ← architecture, waves, dependency diagram
└── tasks/
    ├── 01-cargo-audit-baseline.yml                 (Wave 0 pre-flight)
    ├── 02-git-state-check.yml                      (Wave 0 pre-flight)
    ├── 03-noop-no-patch-this-round.yml             (Wave 1 documented no-op)
    ├── 04-record-auth100-ack.yml                   (Wave 1 ACK note)
    ├── 05-commit-with-pinpoint-trailers.yml        (Wave 1 commit)
    ├── 06-rescan-with-spectre.yml                  (Wave 2 verify; counts unchanged expected)
    ├── 07-propose-accept-handshake-feasibility.yml (Wave 2 follow-up ticket)
    └── 08-cargo-audit-policy.yml                   (Wave 2 follow-up ticket)
```

---

## Pre-flight (one-time, on the audit machine)

```bash
cargo install cargo-audit
```

Pinpoint validated the loop on 2026-05-11; see `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.yml` → `verification.toolchain`.

---

## Running the loop

### Option A — autonomous (recommended)

Hand Claude the audit project and the prompt:

> *Read `claudit/README.md` and `claudit/EPIC.md`. Then execute every task in `claudit/tasks/` in dependency order, halting on first failure. There is no patch to apply this round. Use the ACK note text from `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.yml` → `critical_findings[0].security_notes_text` rather than re-deriving it.*

Claude works through tasks 01 to 06 in one session (~5 minutes), surfaces tasks 07 and 08 as follow-up tickets, and stops.

### Option B — step-by-step

```bash
# Wave 0: pre-flight
claude run claudit/tasks/01-cargo-audit-baseline.yml
claude run claudit/tasks/02-git-state-check.yml

# Wave 1: documented no-op + ACK note + commit (single feature branch)
claude run claudit/tasks/03-noop-no-patch-this-round.yml
claude run claudit/tasks/04-record-auth100-ack.yml
claude run claudit/tasks/05-commit-with-pinpoint-trailers.yml

# Wave 2: re-scan + follow-up tickets
claude run claudit/tasks/06-rescan-with-spectre.yml
claude run claudit/tasks/07-propose-accept-handshake-feasibility.yml
claude run claudit/tasks/08-cargo-audit-policy.yml
```

---

## How tasks reference the YAML

Each task points back to specific keys in `260511-SPECTRE-AUDIT-JITO-RESTAKING-V1.yml` rather than duplicating content. Example from `04-record-auth100-ack.yml`:

```yaml
inputs:
  ack_text_source:    yaml.critical_findings[0].security_notes_text
  scan_commit_marker: e0f02a888cd3dd871e2e101f56758d33f96cdb01
  finding_id:         PINPOINT-JITO-RESTAKING-C-001
```

The agent reads the YAML once, appends the embedded ACK paragraph to the chosen notes file, and moves on. No external file fetches.

---

## Closing the loop

After task 05 lands, the audit-trail commit will carry these trailers:

```
Pinpoint-Finding-Acknowledged: PINPOINT-JITO-RESTAKING-C-001
Pinpoint-Scan-Commit: e0f02a888cd3dd871e2e101f56758d33f96cdb01
```

When V2 ships (against the propose/accept handshake commit, whenever that lands), the trailer chain auto-marks C-001 as `acknowledged-on-V1` in the audit history, and the V2 re-scan should show the AUTH-100 count drop from 6 to ideally 1 (only `ChangeWithdrawalTicketOwner` is expected to remain single-step if the team decides to harmonize all admin handlers).

---

## Confidence

Every task in this graph was rehearsed end-to-end by Pinpoint on the same codebase and same commit on 2026-05-11. The `cargo audit` and SPECTRE scan both ran cleanly; the source reads of all six AUTH-100 sites are recorded in the YAML's `verification.evidence` block. The agent's run is the second pass, not the first.
